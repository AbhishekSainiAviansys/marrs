<?php

$keyId = 'rzp_live_UMziCF38129HCi';
$keySecret = 'nMj5U0daHbD6KxINizRDg8m6';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);




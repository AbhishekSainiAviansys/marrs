<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
    class Login extends CI_Controller 
    {
        public function __construct() {
            parent::__construct();
            $this->load->library('encrypt');
            $this->load->library('session');
        }
        public function index() { 
        
                
            $this->db->where('status', 'Live');
            $this->db->order_by('id', 'DESC');
            $this->db->limit(5);
            $schedules = $this->db->get('competition_product_state')->result();
            
            $queries = []; 
            
            foreach ($schedules as $schedule) {
                $this->db->select('*');
                $this->db->from('cin_uploade');
                $this->db->or_where('status IS NULL', null, false);
                $this->db->where('comp_id',$schedule->id);
                $res = $this->db->get();
                $result = $res->row();
                $cin =  $result->cin;
                
                // $manage = $this->db->get_where('gst_account_marrs',array('id' =>'7','cin'=>$cin))->row();
                
                if ($result) {
                    // echo "CIN: " . $result->cin . "<br>";
                    flush();
                    ob_flush();
                }
            
                sleep(1);
            }
        
            
            if ($this->session->userdata('user_id')) {
                redirect('manage/index/', 'refresh');
            }
            if ($this->session->userdata('user_id') > 0) {
                redirect('manage/index/', 'refresh');
            }
            if (isset($_POST['submit'])) {
                // print_r($_POST['password']);die;
                $this->load->model("loginModel");
                $result = $this->loginModel->loginCheck($_POST['username'],$_POST['password']);
                if (!$result) {
                    $this->notifications->notify('Wrong username/password; Login Failed', 'error');
                } else {
    				
    				
    				/* $this->load->library('email');  
    				$this->email->from('marrsspellingbee.com','Marrs Spelling Bee');  
    				$this->email->to('webteam5@marrs.in');  
    				$this->email->subject('Successfully logged in');  
    				$this->email->message('<b><u>Test Mail</u></b>');  
    				$this->email->send();   */ 
    				
    				
                    // $this->session->set_userdata('user_id', $result['user_id']);
                    // $this->session->set_userdata('username', $result['username']);
                    // redirect('manage/index/', 'refresh');
                    $this->session->set_userdata('user_id', $result['user_id']);
                    $this->session->set_userdata('username', $result['username']);
                    
                    // if(strtolower($result['username']) == 'VishwabashBabu'){    
                        redirect('manage/index', 'refresh');
                    // } else {
                    //   // redirect('manage/franchise/payments', 'refresh');
                    // }
                }
            }
            $this->load->view("login.php");
        }
    
    public function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        redirect('https://marrs.in/', 'refresh');
    }
    
    public function resetpassword()
    {
       
       if(isset($_POST['submit'])){
         $email = $this->input->post('email');
         $this->db->select('*');
         $this->db->from('admin_user');
         $this->db->where('email',$email);
         $res = $this->db->get();
         $result = $res->row();
         $resultemail =  $result->user_id;
         if($resultemail){
            $this->session->set_flashdata('message', 'This Email is valid.');
            redirect('manage/login/updateResetPassword/'.$resultemail);
            }else{
            $this->session->set_flashdata('error', 'This Email is Not valid.'); 
            redirect('manage/login/resetpassword/');
           }
         
       }
     $this->load->view("resetpassword");
    }
    
     public function updateResetPassword()
    {
         $uri= $this->uri->segment(4);
         //print_r($uri);exit;
         if(isset($_POST['submit'])){
         $data = array('password'=>$this->input->post('password'));
         $this->db->where('user_id',$uri);
         $resultstatus = $this->db->update('admin_user',$data);
          if($resultstatus){
            $this->session->set_flashdata('success', 'Password Reset Successfully.');
            redirect('manage/login/');
            }else{
            $this->session->set_flashdata('error', 'Password Reset Failed.'); 
            redirect('manage/login/resetpassword/');
           }
         }
         
      $this->load->view("updateresetpassword");   
    }
    

    
    
}



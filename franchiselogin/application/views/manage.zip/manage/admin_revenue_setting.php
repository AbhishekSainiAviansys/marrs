<?php
	 include('header.php'); 
	 /*$this->session->userdata('session_csvResult_upoload_logArray')*/;
	 
// 	 print_r($result);
	     
	 
 if(!empty($this->session->flashdata('updated'))){?>
<div style="background: green;
    padding: 10px;">
    <h3 style='color:#fff;'><?php echo $this->session->flashdata('updated'); ?></h3>
</div>
<?php
}
?>
    <style>
    div#example_filter {
    float: right;
    position: relative;
    right: 0px;
}
div#example_length {
    position: absolute;
    padding-left: 20px;
}
    
</style>
  
 
<!--<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>-->
<!--<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>-->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>



<div class="row-fluid sortable">
    
	<div class="box span12">
	<!-------------->          
		<div class="box-header well" data-original-title>
			   <h2><i class="icon-edit"></i>Revenue-Price Setting</h2>
    			   <div class="box-icon">
						<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
				   </div>
		</div>
	<!-------------->          
    	<div class="box-content">
    	
    		    <form action="" method="post" > 
    			    <table  cellpadding="5px" width='100%'>
    				    <tr>
    				    	<td>Period: <span style='color:red;'>*</span><br />
                                <select name="period" id="period" style="width: 220px;" required>
                                    <option value="" >-- select period --</option>
                                    
                                    <?php
                                    $query = $this->db->query("SELECT * FROM `period`;");
                                    foreach ($query->result() as $row) {
                                        $selected = (isset($result) && $result['period'] == $row->period_id) ? 'selected' : '';
                                        echo "<option value='{$row->period_id}' $selected>{$row->academic_year}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
    
    					
    					    <td>Product:<span style='color:red;'>*</span><br />
                            <select name="product_id" id="product" style="width: 220px;" required>
                                <option value="" >-- select product --</option>
                                <?php
                                $query = $this->db->query("SELECT * FROM products WHERE status='Active' ORDER BY product_name");
                                foreach ($query->result() as $row) {
                                    $selected = (isset($result) && $result['product_id'] == $row->product_id) ? 'selected' : '';
                                    echo "<option value='{$row->product_id}' $selected>{$row->product_name}</option>";
                                }
                                ?>
                            </select>
                        </td>
    
    
    				
    					    <td>Competition Level:<span style='color:red;'>*</span><br />
    					
    						
                                    <select name="clevel" id="level" style="width: 220px;" required>
                                        <option value="">-- select level --</option>
                                        
                                        <?php
                                        $query = $this->db->query("SELECT * FROM `competition_level_byproduct`;");
                                        foreach ($query->result() as $row) {
                                            $selected = (isset($result) && $result['clevel'] == $row->level_id) ? 'selected' : '';
                                            echo "<option value='{$row->level_id}' $selected>{$row->level_name}</option>";
                                        }
                                        ?>
                                    </select>
    
                            </td>          
    				
    					    <td>Management Percentage <span style='color:red;'>*</span><br>
                                <select name="manageper" style="width: 220px;" required>
                                    <option value="">-- select management % --</option>
                                    <?php
                                    $percentages = [2,3,4,5, 8, 10, 12, 15, 16, 18, 20, 22];
                                    foreach ($percentages as $percent) {
                                        $selected = (isset($result) && $result['manageper'] == $percent) ? 'selected' : '';
                                        echo "<option value='$percent' $selected>$percent%</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                            
                            <td>Aviansys Percentage <span style='color:red;'>*</span><br>
                                <select name="com_peravian" style="width: 220px;" required>
                                    <option value="">-- select aviansys % --</option>
                                    <?php
                                    $percentages = [2,3,4,5, 8, 10, 12, 15, 16, 18, 20, 22, 25, 30];
                                    foreach ($percentages as $percent) {
                                        $selected = (isset($result) && $result['com_peravian'] == $percent) ? 'selected' : '';
                                        echo "<option value='$percent' $selected>$percent%</option>";
                                    }
                                    ?>
                                </select>
                            </td>
    
    			
        				</tr> 
        				
        				<tr>
    				    
    				        <td>Associate Percentage<br>
                                <select name="associate_per" style="width: 220px;">
                                    <option value="">-- select associate % --</option>
                                    <?php
                                    $percentages = range(5, 60, 5); // 5, 10, ..., 60
                                    foreach ($percentages as $percent) {
                                        $selected = (isset($result) && $result['associate_per'] == $percent) ? 'selected' : '';
                                        echo "<option value='$percent' $selected>$percent%</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                            
                            <td>Franchise Percentage<br>
                                <select name="com_per" style="width: 220px;">
                                    <option value="">-- select franchise % --</option>
                                    <?php
                                    foreach ($percentages as $percent) {
                                        $selected = (isset($result) && $result['com_per'] == $percent) ? 'selected' : '';
                                        echo "<option value='$percent' $selected>$percent%</option>";
                                    }
                                    ?>
                                </select>
                            </td>
    
    				   
    				        <!--<td> CRM Fix <span style='color:red;'>*</span><br>-->
        				    <!--    <input type='text' name='crm_fix' style="width: 220px;" value="<?php if($result['crm_fix']){ echo $result['crm_fix']; } ?>" >-->
        				    <!--</td>-->
    				        
    				        <td>CRM %<span style='color:red;'>*</span><br>
                                <select name="crm_per" style="width: 220px;" >
                                    <option value="">-- select CRM % --</option>
                                    <?php
                                    $percentages = [0,1,2,3,4,5,6,7,8,9,10];
                                    foreach ($percentages as $percent) {
                                        $selected = (isset($result) && $result['crm_per'] == $percent) ? 'selected' : '';
                                        echo "<option value='$percent' $selected>$percent%</option>";
                                    }
                                    ?>
                                </select>
                            </td>
    				    
        				    <hr>
        				    <td id='product_price'> Competition Registration Price <span style='color:red;'>*</span><br>
        				        <input type='text' name='product_price' style="width: 210px;" value="<?php if($result['product_price']){ echo $result['product_price']; } ?>" >
        				    </td>
        				    
        				    <td>
        				        Free Material Royalty <span style='color:red;'>*</span><br>
        				        <input type='text' name='study_material_free_royalty' style="width: 210px;" value="<?php if($result['study_material_free_royalty']){ echo $result['study_material_free_royalty']; } ?>" required>
        				    
        				    </td>
        				    
    				    </tr>
    				
        				<tr>
        				    
        				    
        				    <td> Material-A Price <br>
        				        <input type='text' name='study_material_a_price' style="width: 100px;" value="<?php if($result['study_material_a_price']){ echo $result['study_material_a_price']; } ?>">
        				        <br>
        				        Material-A Royalty <br>
        				        <input type='text' name='study_material_a_price_royalty' style="width: 100px;" value="<?php if($result['study_material_a_price_royalty']){ echo $result['study_material_a_price_royalty']; } ?>" >
        				    </td>
        				    <td> Material-B Price <br>
        				        <input type='text' name='study_material_b_price' style="width: 100px;" value="<?php if($result['study_material_b_price']){ echo $result['study_material_b_price']; } ?>">
        				        <br>
        				        Material-B Royalty <br>
        				        <input type='text' name='study_material_b_price_royalty' style="width: 100px;" value="<?php if($result['study_material_b_price_royalty']){ echo $result['study_material_b_price_royalty']; } ?>">
        				    
        				    </td>
        				    <td> Material-C Price <br>
        				        <input type='text' name='study_material_c_price' style="width: 100px;" value="<?php if($result['study_material_c_price']){ echo $result['study_material_c_price']; } ?>">
        				        <br>Material-C Royalty <br>
        				        <input type='text' name='study_material_c_price_royalty' style="width: 100px;" value="<?php if($result['study_material_c_price_royalty']){ echo $result['study_material_c_price_royalty']; } ?>">
        				    
        				    </td>
        				    <td> Material-D Price <br>
        				        <input type='text' name='study_material_d_price' style="width: 100px;" value="<?php if($result['study_material_d_price']){ echo $result['study_material_d_price']; } ?>">
        				        <br>Material-D Royalty <br>
        				        <input type='text' name='study_material_d_price_royalty' style="width: 100px;" value="<?php if($result['study_material_d_price_royalty']){ echo $result['study_material_d_price_royalty']; } ?>">
        				    
        				    </td>
        				    <td> Material-E Price <br>
        				        <input type='text' name='study_material_e_price' style="width: 100px;" value="<?php if($result['study_material_e_price']){ echo $result['study_material_e_price']; } ?>">
        				        <br>Material-F Royalty <br>
        				        <input type='text' name='study_material_e_price_royalty' style="width: 100px;" value="<?php if($result['study_material_e_price_royalty']){ echo $result['study_material_e_price_royalty']; } ?>">
        				    
        				    </td>
        				    <td> Material-F Price<br>
        				        <input type='text' name='study_material_f_price' style="width: 100px;" value="<?php if($result['study_material_f_price']){ echo $result['study_material_f_price']; } ?>">
        				        <br>Material-F Royalty<br>
        				        <input type='text' name='study_material_f_price_royalty' style="width: 100px;" value="<?php if($result['study_material_f_price_royalty']){ echo $result['study_material_f_price_royalty']; } ?>">
        				    
        				    </td>
        				    
        				    
        				</tr>
        				
        				<tr>
        				    <td colspan='11'></td>
        				</tr>
    				
    				<!--<tr>-->
    				    
    				    
    				<!--        <td> Orientation-A Price <br>-->
        <!--				        <input type='text' name='orientation_a_price' style="width: 210px;" value="<?php if($result['orientation_a_price']){ echo $result['orientation_a_price']; } ?>">-->
        <!--				    </td>-->
        <!--				    <td> Orientation-B Price <br>-->
        <!--				        <input type='text' name='orientation_b_price' style="width: 210px;" value="<?php if($result['orientation_b_price']){ echo $result['orientation_b_price']; } ?>">-->
        <!--				    </td>-->
        <!--				    <td> Orientation-C Price <br>-->
        <!--				        <input type='text' name='orientation_c_price' style="width: 210px;" value="<?php if($result['orientation_c_price']){ echo $result['orientation_c_price']; } ?>">-->
        <!--				    </td>-->
    				    
    				<!--        <td> Orientation-D Price <br>-->
        <!--				        <input type='text' name='orientation_a_price' style="width: 210px;" value="<?php if($result['orientation_d_price']){ echo $result['orientation_d_price']; } ?>">-->
        <!--				    </td>-->
        <!--				    <td> Orientation-E Price <br>-->
        <!--				        <input type='text' name='orientation_b_price' style="width: 210px;" value="<?php if($result['orientation_e_price']){ echo $result['orientation_e_price']; } ?>">-->
        <!--				    </td>-->
        <!--				    <td> Orientation-F Price <br>-->
        <!--				        <input type='text' name='orientation_c_price' style="width: 210px;" value="<?php if($result['orientation_f_price']){ echo $result['orientation_f_price']; } ?>">-->
        <!--				    </td>-->
    				    
    				    
    				<!--</tr>-->
    				
    				<tr>
                        <td> Orientation-A Price <br>
                            <input type='text' name='orientation_a_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_a_price'])){ echo $result['orientation_a_price']; } ?>">
                        </td>
                        <td> Orientation-B Price <br>
                            <input type='text' name='orientation_b_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_b_price'])){ echo $result['orientation_b_price']; } ?>">
                        </td>
                        <td> Orientation-C Price <br>
                            <input type='text' name='orientation_c_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_c_price'])){ echo $result['orientation_c_price']; } ?>">
                        </td>
                        <td> Orientation-D Price <br>
                            <input type='text' name='orientation_d_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_d_price'])){ echo $result['orientation_d_price']; } ?>">
                        </td>
                        <td> Orientation-E Price <br>
                            <input type='text' name='orientation_e_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_e_price'])){ echo $result['orientation_e_price']; } ?>">
                        </td>
                        <td> Orientation-F Price <br>
                            <input type='text' name='orientation_f_price' style="width: 210px;" 
                                value="<?php if(!empty($result['orientation_f_price'])){ echo $result['orientation_f_price']; } ?>">
                        </td>
                    </tr>
    
    				
    				<tr>
    				    <td> MockTest-A Price <br>
    				        <input type='text' name='mock_test_a_price' style="width: 100px;" value="<?php if($result['mock_test_a_price']){ echo $result['mock_test_a_price']; } ?>">
    				        <br>MockTest-A Royalty<br>
    				        <input type='text' name='mock_test_a_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_a_price_royalty']){ echo $result['mock_test_a_price_royalty']; } ?>">
    				    
    				    </td>
    				    <td> MockTest-B Price <br>
    				        <input type='text' name='mock_test_b_price' style="width: 100px;" value="<?php if($result['mock_test_b_price']){ echo $result['mock_test_b_price']; } ?>">
    				        <br>MockTest-B Royalty<br>
    				        <input type='text' name='mock_test_b_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_b_price_royalty']){ echo $result['mock_test_b_price_royalty']; } ?>">
    				    
    				    </td>
    				    <td> MockTest-C Price <br>
    				        <input type='text' name='mock_test_c_price' style="width: 100px;" value="<?php if($result['mock_test_c_price']){ echo $result['mock_test_c_price']; } ?>">
    				        <br>MockTest-C Royalty<br>
    				        <input type='text' name='mock_test_c_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_c_price_royalty']){ echo $result['mock_test_c_price_royalty']; } ?>">
    				    
    				    </td>
    				    <td> MockTest-D Price <br>
    				        <input type='text' name='mock_test_d_price' style="width: 100px;" value="<?php if($result['mock_test_d_price']){ echo $result['mock_test_d_price']; } ?>">
    				        <br>MockTest-D Royalty<br>
    				        <input type='text' name='mock_test_d_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_d_price_royalty']){ echo $result['mock_test_d_price_royalty']; } ?>">
    				    
    				    </td>
    				    <td> MockTest-E Price <br>
    				        <input type='text' name='mock_test_e_price' style="width: 100px;" value="<?php if($result['mock_test_e_price']){ echo $result['mock_test_e_price']; } ?>">
    				        <br>MockTest-E Royalty<br>
    				        <input type='text' name='mock_test_e_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_e_price_royalty']){ echo $result['mock_test_e_price_royalty']; } ?>">
    				    
    				    </td>
    				    <td> MockTest-F Price <br>
    				        <input type='text' name='mock_test_f_price' style="width: 100px;" value="<?php if($result['mock_test_f_price']){ echo $result['mock_test_f_price']; } ?>">
    				        <br>MockTest-F Royalty<br>
    				        <input type='text' name='mock_test_f_price_royalty' style="width: 100px;" value="<?php if($result['mock_test_f_price_royalty']){ echo $result['mock_test_f_price_royalty']; } ?>">
    				    
    				    </td>
    				    
    				    
    			            
    				     
    				    
    				</tr>
    				
    				<tr>
    				    <td> <br /><input type="submit" name="submit" value="Submit" class='btn btn-info btn-lg' /> </td>
    			            <!--<input type="submit" name="ok" value="" />-->
    				</tr>
    				
    		   </table>		 
    		 
    		    <br />
    		</form>
    		
    	 
        </div>	
        
    </div><!--/span-->
    
</div><!--/row-->

    <?php if(isset($message)){ ?>
        <h2><?php echo $message; ?></h2>
   <?php } ?>
   
   <?php if(isset($message1)){ ?>
        <h2><?php echo $message1; ?></h2>
   <?php } ?>
   
   
    <div class="row-fluid sortable">
    
    
            <form  method="POST">
            
                <div class="box span12">
                
    			        <div class="box-header well" data-original-title>
    						<h2><i class="icon-user"></i>Search Revenue Setting</h2>
    
    					</div>
    					
    		        <table  cellpadding="5px" width='100%'>
        			    <tr>
        			    	<td>Period: <span style='color:red;'>*</span><br />
                                <select name="period" id="period" style="width: 220px;" required>
                                    <option value="" >-- select period --</option>
                                    
                                    <?php
                                    $query = $this->db->query("SELECT * FROM `period` where period_id > 13;");
                                    foreach ($query->result() as $row) {
                                        $selected = (isset($ress) && $ress['period'] == $row->period_id) ? 'selected' : '';
                                        echo "<option value='{$row->period_id}' $selected>{$row->academic_year}</option>";
                                    }
                                    ?>
                                </select>
                            </td>
        
        				
        				    <td>Product:<span style='color:red;'>*</span><br />
                                <select name="product_id" id="product1" style="width: 220px;" required>
                                    <option value="" >-- select product --</option>
                                    
                                        <?php
                                        $query = $this->db->query("SELECT * FROM products WHERE status='Active' ORDER BY product_name");
                                        foreach ($query->result() as $row) {
                                            $selected = (isset($ress) && $ress['product_id'] == $row->product_id) ? 'selected' : '';
                                            echo "<option value='{$row->product_id}' $selected>{$row->product_name}</option>";
                                        }
                                        ?>
                                </select>
                            </td>
        
        
        			
        				    <td>Competition Level:<span style='color:red;'>*</span><br />
                                <select name="clevel" id="level1" style="width: 220px;" required>
                                    <option value="">-- select level --</option>
                                    
                                    <?php
                                        if(isset($ress)){
                                            foreach ($level_load as $row) {
                                                $selected = (isset($ress) && $ress['clevel'] == $row->level_id) ? 'selected' : '';
                                                echo "<option value='{$row->level_id}' $selected>{$row->level_name}</option>";
                                            }
                                        }
                                    ?>
                                </select>
        
                            </td>          
        			
        				   
        			
        			        <td> <br /><input type="submit" name="search" value="search" class='btn btn-warning btn-lg' /> </td>
        		           
        			    </tr>
    			    
    	            </table>		 
    		 
    		    </div>  
    		
    	    </form>
  
        
			<div>		
				<div class="box span12">
				    
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i>Revenue Setting Last 10 Added List or filtered setting list</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					
					<div class="box-content" style="margin:10px">
                  
    					<table  id="example" class="table table-striped table-bordered" style="width:100%;">
    					    
                	        <thead>
                        			<tr>
                        	            <th>Sr. No.</th>
                        	            <th> Product </th>
                        	            <th> Period </th>
                        	            <th> Level </th>
                        	            <th> CRM </th>
                        	            <th> Franchise </th>
                        	            <th> Management </th>
                        	            <th> Associate </th>
                        	            <th> Registration Price </th>
                        	            <th> Material Price </th>
                        	            <th> MockTest Price</th>
                        	            <th> Orientation Price</th>
                        	            <th> Option</th>
                        	        </tr>
                	          </thead> 
                	          
                	        <form method="POST">
                	            
    				            <tbody>
            	                <?php if(!empty($list_materials)){
            	            //print_r($list_materials);
            	           
            	            $i=1;
            	            foreach($list_materials as $row){ //print_r($row);die;
            	            ?>
    	           
        	            <tr>
        	                <td><?php echo $i;?></td>
        	                <td><?php 
    	                    if($row['product_name'] == 'Lunar Skill Test'){
    	                        echo $row['product_name'].'<br>';
    	                        echo $row['subject'].'<br>';
    	                        echo $row['sub_type'].'<br>';
    	                        echo $row['series'];
    	                    }else{
    	                        echo $row['product_name']; 
    	                    }
    	                ?></td>
    	                <td><?php 
    	                    
    	                            $query = $this->db->query("SELECT academic_year FROM period where period_id='{$row['period_id']}' ");
    									    $result=$query->row();
    	                            echo $result->academic_year; 
    	                    ?>
    	                </td>
    	                <td><?php 
    	                
    	                    $query = $this->db->query("SELECT level_name FROM competition_level_byproduct where level_id='{$row['clevel']}' and product_name='{$row['product_name']}' ");
    									    
    									    $result=$query->row();
    									   // print_r($result);
    									    echo $result->level_name;
    									    
    	                   // echo $row['clevel'].$row['product_name']; 
    	                
    	                ?></td>
    	                <td><?php echo $row['crm_fix'].' Rs'; ?></td>
    	                <td>
    	                    <?php 
    	                    
    	                    //echo $row['com_per'];
    	                    
    	                    
    									if(!empty($row['com_per'])){
    									    
    									    echo $row['com_per'].' %';
    									    
    									}
    									else{
    									    echo 'Not Assigned to franchise.';  
    									}
    									
    									?>
    	                </td>
    	                
    	                <td>
    	                            <?php if(!empty($row['manageper'])){
    									    
    									    echo $row['manageper'].' %';
    									    
    									}
    									else{
    									    echo 'Not Assigned to Management.';  
    									}
    									
    									?>
    					</td>
    					
    	                <td><?php 
    	                                if(!empty($row['associate_per'])){
    									    
    									    echo $row['associate_per'].' %';
    									    
    									}
    									else{
    									    echo 'Not Assigned to associate.';  
    									}
    									
    									?>
    					</td>
    	                <td>
    	                    <?php 
    	                        echo $row['product_price'].' Rs'; 
    	                        echo '<br> Free Material Royalty:'.$row['study_material_free_royalty'].' Rs';
    	                    ?>
    	                </td>
    	                
    	                <td><?php echo 'A : '.$row['study_material_a_price'].' Royalty '.$row['study_material_a_price_royalty'].'<br> B : '.$row['study_material_b_price'].' Royalty '.$row['study_material_b_price_royalty'].'<br> C : '.$row['study_material_c_price'].' Royalty '.$row['study_material_c_price_royalty'].'<br> D : '.$row['study_material_d_price'].' Royalty '.$row['study_material_d_price_royalty'].'<br> E : '.$row['study_material_e_price'].' Royalty '.$row['study_material_e_price_royalty'].'<br> F : '.$row['study_material_f_price'].' Royalty '.$row['study_material_f_price_royalty']; ?></td>
    	                
    	                <td><?php echo 'A : '.$row['mock_test_a_price'].' Royalty '.$row['mock_test_a_price_royalty'].'<br> B : '.$row['mock_test_b_price'].' Royalty '.$row['mock_test_b_price_royalty'].'<br> C : '.$row['mock_test_c_price'].' Royalty '.$row['mock_test_c_price_royalty'].'<br> D : '.$row['mock_test_d_price'].' Royalty '.$row['mock_test_d_price_royalty'].'<br> E : '.$row['mock_test_e_price'].' Royalty '.$row['mock_test_e_price_royalty'].'<br> E : '.$row['mock_test_f_price'].' Royalty '.$row['mock_test_f_price_royalty']; ?></td>
    	                
    	                <td><?php echo 'A : '.$row['orientation_a_price'].'<br> B : '.$row['orientation_b_price'].'<br> C : '.$row['orientation_c_price']; ?></td>
    	                
    	                
    	                 <td align="CENTER">
                            <button 
                                name="delete" 
                                value="<?php echo $row['id']; ?>" 
                                class="btn btn-danger"
                                onclick="return confirm('Are you sure you want to delete this entry ?');"
                            >
                                Delete
                            </button>
                            
                            <a 
                                href="https://marrs.in/franchiselogin/manage/franchise/admin_revenue_setting_edit/<?php echo $row['id']; ?>" 
                                class="btn btn-primary"
                                
                            >
                                Edit
                            </a>
                            
                        </td>
    
    					  
    	            </tr>
    	        <?php 
    	           $i++; }
    	       }?>
    	       	                </tbody>
    	       	            
    	       	            </form>
    	       	            
    	                </table>
    	                
				    </div><!--/span-->
			
			    </div>
			</div>
    

    
    </div>



<script>

    

$(document).ready(function() {
    
    
    // When product changes in search form
    $("#product1").change(function() {
        var product_id = this.value;

        $.ajax({
            url: "https://marrs.in/franchiselogin/manage/ajax/productwiselevel",
            data: { product_id: product_id },
            type: 'POST',
            success: function(result) {
                $("#level1").html(result);
            },
            error: function() {
                alert("An error occurred while fetching data.");
            }
        });
    });

    // Show/hide product price based on level in search form
    $("#level1").change(function() {
        if (this.value === "1") {
            $('#product_price').hide();
        } else {
            $('#product_price').show();
        }
    });

    // Optional: Trigger on load to set state
    $("#level1").trigger('change');
});
</script>



<script>
$(document).ready(function() {
    
    
    
    // Hide these divs initially
    $('#subjectdiv').hide();
    $('#varientdiv').hide();
    $('#seriesdiv').hide();

    $("#product").change(function() {
        var product_id = this.value;

        if (product_id === '8') {  // Compare as string
            $('#subjectdiv').show();
            $('#varientdiv').show();
            $('#seriesdiv').show();
        } else {
            $('#subjectdiv').hide();
            $('#varientdiv').hide();
            $('#seriesdiv').hide();
        }

        $.ajax({
            url: "https://marrs.in/franchiselogin/manage/ajax/productwiselevel",
            data: { product_id: product_id },
            type: 'POST',
            success: function(result) {
                $("#level").html(result);
            },
            error: function() {
                alert("An error occurred while fetching data.");
            }
        });
    });
    
    $("#subject").change(function() {
        var subject_key = this.value;

        

        $.ajax({
            url: "https://marrs.in/franchiselogin/manage/ajax/getlunar_subject_key",
            data: { subject_key: subject_key },
            type: 'POST',
            success: function(result) {
                $("#varient").html(result);
            },
            error: function() {
                alert("An error occurred while fetching data.");
            }
        });
    });
    
    $("#varient").change(function() {
        var varient = this.value;
        var subject_key = $('#subject').val();
        var period = $('#period').val();


        $.ajax({
            url: "https://marrs.in/franchiselogin/manage/ajax/getlunar_series",
            data: { subject_key: subject_key,varient:varient,period:period },
            type: 'POST',
            success: function(result) {
                $("#series").html(result);
            },
            error: function() {
                alert("An error occurred while fetching data.");
            }
        });
    });
    
    $("#product1").change(function() {
        var product_id = this.value;
        $.ajax({
            url: "https://marrs.in/franchiselogin/manage/ajax/productwiselevel",
            data: { product_id: product_id },
            type: 'POST',
            success: function(result) {
                $("#level1").html(result);
            },
            error: function() {
                alert("An error occurred while fetching data.");
            }
        });
    });
});
</script>


<script>
$(document).ready(function() {
    $("#level").change(function() {
        if (this.value === "1") { // compare with string
            $('#product_price').hide();
        } else {
            $('#product_price').show();
        }
    });

    // Optional: Trigger change on load to reflect initial state
    $("#level").trigger('change');
});
</script>



<?php include('footer.php'); ?>
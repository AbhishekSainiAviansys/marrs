<?php include('header.php'); ?>

<style>
/* ===== SHARED TOGGLE STYLES ===== */
.toggle { position: relative; width: 42px; height: 22px; display: inline-block; }
.toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
.slider { position: absolute; inset: 0; background: #D3D1C7; border-radius: 11px; cursor: pointer; transition: background .2s; }
.slider:before { content: ''; position: absolute; width: 16px; height: 16px; left: 3px; top: 3px; background: #fff; border-radius: 50%; transition: transform .2s; }
.toggle input:checked + .slider { background: #1D9E75; }
.toggle input:checked + .slider:before { transform: translateX(20px); }
.sw-wrap { display: flex; align-items: center; gap: 6px; }
.sw-lbl { font-size: 11px; color: #888; min-width: 38px; }
.cin-wrap { display: flex; align-items: center; gap: 6px; }
.cbtn { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; padding: 4px 9px; border-radius: 6px; border: 1px solid transparent; text-decoration: none; white-space: nowrap; cursor: pointer; }
.cbtn-green { background: #E1F5EE; border-color: #5DCAA5; color: #0F6E56; }
.cbtn-blue  { background: #E6F1FB; border-color: #85B7EB; color: #185FA5; }
.cbtn-amber { background: #FAEEDA; border-color: #FAC775; color: #854F0B; }
.cbtn-gray  { background: #F1EFE8; border-color: #D3D1C7; color: #888; opacity: .5; pointer-events: none; }

/* ===== SHARED MODAL STYLES ===== */
#compModeModal,
#cinModeModal,
#cinOfflineDateModal {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.45);
  z-index: 9999;
  align-items: center;
  justify-content: center;
}
#compModeModal.show,
#cinModeModal.show,
#cinOfflineDateModal.show {
  display: flex;
}
.cm-modal-box {
  background: #fff;
  border-radius: 10px;
  padding: 28px 32px;
  width: 380px;
  box-shadow: 0 8px 32px rgba(0,0,0,.18);
}
.cm-modal-box h4 { margin: 0 0 6px; font-size: 16px; color: #1a1a1a; }
.cm-modal-box p.cm-subtitle { margin: 0 0 20px; font-size: 12px; color: #888; }
.cm-field { margin-bottom: 14px; }
.cm-field label { display: block; font-size: 12px; color: #555; margin-bottom: 4px; font-weight: 600; }
.cm-field input {
  width: 100%; padding: 8px 10px; border: 1px solid #ccc;
  border-radius: 6px; font-size: 13px; box-sizing: border-box; transition: border-color .15s;
}
.cm-field input:focus { outline: none; border-color: #1D9E75; }
.cm-error { color: #c0392b; font-size: 12px; margin-bottom: 12px; display: none; padding: 6px 10px; background: #fdecea; border-radius: 5px; }
.cm-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
.cm-btn-cancel { padding: 8px 20px; border-radius: 6px; border: 1px solid #ccc; background: #f1efe8; cursor: pointer; font-size: 13px; }
.cm-btn-save   { padding: 8px 20px; border-radius: 6px; border: none; background: #1D9E75; color: #fff; cursor: pointer; font-size: 13px; font-weight: 600; }
.cm-btn-save:hover   { background: #178a64; }
.cm-btn-cancel:hover { background: #e4e2db; }

/* ===== ACTIVATE MODAL STYLES ===== */
#checkAll { cursor: pointer; }
#activateModal {
  display: none;
  align-items: center;
  justify-content: center;
}
#activateModal > div {
  font-family: Arial, sans-serif;
  width: 960px !important;
  max-width: 97%;
  max-height: 90vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
#activateModal h4 { font-size: 18px; font-weight: 600; margin-bottom: 12px; }

/* Product list row columns */
#productList .product-row { display:flex; align-items:center; border-bottom:1px solid #f5f5f5; padding:4px 0; }
#productList .col-check   { width:40%; display:flex; align-items:center; gap:6px; font-size:13px; color:#333; cursor:pointer; margin:0; }
#productList .col-price   { width:30%; padding-right:4px; }
#productList .col-level   { width:30%; }
#productList select.chk {
  margin-top: 0 !important;
  margin-left: 0 !important;
  width: 100%;
  padding: 2px 6px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 12px;
}
#productList::-webkit-scrollbar { width: 6px; }
#productList::-webkit-scrollbar-thumb { background: #ccc; border-radius: 10px; }

/* Selected products summary panel */
#selectedSummary {
  background: #f7f9f7;
  border: 1px solid #c8e6d8;
  border-radius: 8px;
  padding: 10px 14px;
  margin-top: 12px;
  min-height: 48px;
}
#selectedSummary .sum-title {
  font-size: 11px;
  font-weight: 700;
  color: #1D9E75;
  text-transform: uppercase;
  letter-spacing: .04em;
  margin-bottom: 6px;
}
#selectedSummary .sum-empty { font-size: 12px; color: #aaa; font-style: italic; }
#selectedSummary .sum-list  { display: flex; flex-wrap: wrap; gap: 6px; }
#selectedSummary .sum-tag   {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  background: #E1F5EE;
  border: 1px solid #5DCAA5;
  border-radius: 20px;
  padding: 3px 10px 3px 8px;
  font-size: 11px;
  color: #0F6E56;
  white-space: nowrap;
}
#selectedSummary .sum-tag .sum-meta { color: #4a9e80; font-size: 10px; }
</style>

<!-- ===== COMPETITION MODE MODAL ===== -->
<div id="compModeModal">
  <div class="cm-modal-box">
    <h4>Set Competition Mode Details</h4>
    <p class="cm-subtitle">Please fill in the dates before switching to Online mode.</p>
    <div class="cm-field">
      <label>Start Date <span style="color:#e00;">*</span></label>
      <input type="date" id="cm_start_date">
    </div>
    <div class="cm-field">
      <label>End Date <span style="color:#e00;">*</span></label>
      <input type="date" id="cm_end_date">
    </div>
    <div class="cm-error" id="cm_error"></div>
    <div class="cm-actions">
      <button class="cm-btn-cancel" onclick="cancelCompMode()">Cancel</button>
      <button class="cm-btn-save"   onclick="saveCompMode()">Save &amp; Activate</button>
    </div>
  </div>
</div>

<!-- ===== CIN ONLINE MODAL ===== -->
<div id="cinModeModal">
  <div class="cm-modal-box">
    <h4>Registration Active Date</h4>
    <p class="cm-subtitle">Please fill in the dates before switching to Online mode.</p>
    <div class="cm-field">
      <label>Start Date <span style="color:#e00;">*</span></label>
      <input type="date" id="cin_start_date">
    </div>
    <div class="cm-field">
      <label>End Date <span style="color:#e00;">*</span></label>
      <input type="date" id="cin_end_date">
    </div>
    <div class="cm-error" id="cin_error"></div>
    <div class="cm-actions">
      <button class="cm-btn-cancel" onclick="cancelCinMode()">Cancel</button>
      <button class="cm-btn-save"   onclick="saveCinMode()">Save &amp; Activate</button>
    </div>
  </div>
</div>

<!-- ===== CIN OFFLINE MODAL ===== -->
<div id="cinOfflineDateModal">
  <div class="cm-modal-box">
    <h4>Set Competition Date</h4>
    <p class="cm-subtitle">Enter the competition date for offline registration.</p>
    <div class="cm-field">
      <label>Competition Date <span style="color:#e00;">*</span></label>
      <input type="date" id="cin_comp_date">
    </div>
    <div class="cm-error" id="cin_offline_error"></div>
    <div class="cm-actions">
      <button class="cm-btn-cancel" onclick="cancelCinOfflineMode()">Cancel</button>
      <button class="cm-btn-save"   onclick="saveCinOfflineMode()">Save</button>
    </div>
  </div>
</div>

<div>
  <ul class="breadcrumb">
    <li><a href="<?php echo SITE_URL?>school/">School</a> <span class="divider">/</span></li>
    <li>School List</li>
  </ul>
</div>

<div>
  <div class="box span12">
    <div class="box-header well" data-original-title>
      <h2><i class="icon-user"></i> School List</h2>
      <div class="box-icon">
        <a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
        <a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
      </div>
    </div>

    <div class="box-content">

      <div id="flash-message" style="display:none; padding:10px; border-radius:5px; margin-bottom:10px;"></div>

      <?php if ($this->session->flashdata('success')) { ?>
        <div style="padding:10px; background:#d4edda; color:#155724; border-radius:5px; margin-bottom:10px;">
          <?php echo $this->session->flashdata('success'); ?>
        </div>
      <?php } ?>

      <!-- ===== FILTER FORM ===== -->
      <form method="POST" id="filterForm">
        <div style="display:flex; flex-wrap:wrap; gap:16px; align-items:flex-end; margin-bottom:16px;">

          <div>
            <label class="control-label">State <span style="color:#F00;font-size:15px;"><b>*</b></span></label>
            <div class="controls">
              <select name="state_id" id="state_id" style="width:200px;">
                <option value=''>Select State</option>
                <?php
                  $query = $this->db->order_by('state_subdivision_name','ASC')
                                    ->get_where('states', array('country_id'=>'105'))->result();
                  foreach ($query as $row) { ?>
                  <option value="<?php echo $row->state_subdivision_id; ?>"
                    <?php if($row->state_subdivision_id == $result['state_id']) echo 'selected="selected"'; ?>>
                    <?php echo $row->state_subdivision_name; ?>
                  </option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div>
            <label class="control-label">Franchise <span style="color:#F00;font-size:15px;"><b>*</b></span></label>
            <div class="controls">
              <select name="franchise" id="franchise" style="width:200px;">
                <option value=''>Select Franchise</option>
                <?php if(isset($result['franchise']) && $result['franchise']=='All') { ?>
                  <option value="All" selected="selected">All Franchise</option>
                <?php } ?>
                <?php foreach($franchise_load as $value) { ?>
                  <option value="<?php echo $value['franchise_id']; ?>"
                    <?php if($result['franchise'] == $value['franchise_id']) echo 'selected="selected"'; ?>>
                    <?php echo $value['username']; ?>
                  </option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div>
            <label class="control-label">Area Code <span style="color:#F00;font-size:15px;"><b>*</b></span></label>
            <div class="controls">
              <select name="area_code" id="area" style="width:200px;">
                <?php if(isset($result['area_code']) && $result['area_code']=='All') { ?>
                  <option value="All" selected="selected">All Area</option>
                <?php } ?>
                <option value=''>-- Select Area --</option>
                <?php foreach($area_load as $servicelistval) { ?>
                  <option value="<?php echo $servicelistval['area_code']; ?>"
                    <?php if($result['area_code'] == $servicelistval['area_code']) echo 'selected="selected"'; ?>>
                    <?php echo $servicelistval['city_name']; ?>
                  </option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div>
            <label class="control-label">Status <span style="color:#F00;font-size:15px;"><b>*</b></span></label>
            <div class="controls">
              <select name="status" id="status" style="width:200px;">
                <option value="All"      <?php if($result['status']=='All')      echo 'selected'; ?>>All</option>
                <option value="Active"   <?php if($result['status']=='Active')   echo 'selected'; ?>>Active</option>
                <option value="Pending"  <?php if($result['status']=='Pending')  echo 'selected'; ?>>Pending</option>
                <option value="Inactive" <?php if($result['status']=='Inactive') echo 'selected'; ?>>Inactive</option>
                <option value="Deleted"  <?php if($result['status']=='Deleted')  echo 'selected'; ?>>Deleted</option>
                <option value="Deactive" <?php if($result['status']=='Deactive') echo 'selected'; ?>>Deactive</option>
              </select>
            </div>
          </div>

          <div class="form-actions" style="margin:0;">
            <input type="submit" class="btn btn-primary" value="Submit" name="submit">
          </div>

        </div>
      </form>
      <!-- ===== END FILTER FORM ===== -->

      <?php if(!empty($schoolList)) { ?>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
          <h4>Total Schools: <?php echo count($schoolList); ?></h4>
          <form method="POST">
            <input type="hidden" name="state_id" value="<?php echo $result['state_id']; ?>">
            <input type="hidden" name="franchise" value="<?php echo $result['franchise']; ?>">
            <input type="hidden" name="area_code" value="<?php echo $result['area_code']; ?>">
            <input type="hidden" name="status"    value="<?php echo $result['status']; ?>">
            <input type="submit" class="btn btn-warning" value="Export CSV" name="export">
          </form>
        </div>

        <div style="overflow-x:auto;">
        <table class="table table-bordered" style="width:100%; font-size:12px;">
          <thead>
            <tr>
              <th>Sl no</th>
              <th>School code</th>
              <th>School name</th>
              <th>Address</th>
              <th>State</th>
              <th>City</th>
              <th>Franchise</th>
              <th>School Status</th>
              <th>School level activation</th>
              <th>Registration mode</th>
              <th>Competition mode</th>
              <th>School Details</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
          <?php $i = 1; foreach($schoolList as $value) {

            $activeschool = $this->db->get_where('product_to_school', array(
              'school_id' => $value['id'],
              'period_id' => '16'
            ))->row();
            $isActive = !empty($activeschool);

            $pts = $this->db->get_where('product_to_school', array(
                'school_id' => $value['id'],
                'period_id' => '16'
            ))->row_array();

            $compMode  = !empty($pts['competition_mode'])   ? $pts['competition_mode']
                       : (isset($value['competition_mode']) ? $value['competition_mode'] : 'offline');

            $regMode   = !empty($pts['registration_mode'])  ? $pts['registration_mode']
                       : (isset($value['registration_mode'])? $value['registration_mode']: 'offline');

            $isOnline  = ($compMode === 'online');
            $regOnline = ($regMode  === 'online');
          ?>
            <tr id="school-row-<?php echo $value['id']; ?>">

              <td><?php echo $i; ?></td>
              <td style="font-family:monospace; font-size:11px;"><?php echo $value['school_code']; ?></td>
              <td style="font-weight:500;"><?php echo $value['school_name']; ?></td>
              <td><?php echo $value['school_address'] . ' ' . $value['city']; ?></td>
              <td><?php echo $value['state_subdivision_name']; ?></td>
              <td><?php echo $value['city']; ?></td>
              <td style="font-size:11px;"><?php echo $value['franchise_code'] . ' ' . $value['franchise_first_name']; ?></td>
              <td><?php echo $value['school_status']; ?></td>

              <!-- ===== SCHOOL LEVEL ACTIVATION ===== -->
              <td>
                <?php if($value['status_new'] == 'Inactive' || empty($value['status_new'])) { ?>
                  <a href="javascript:void(0);"
                     class="btn btn-warning btn-activate"
                     style="font-size:11px;"
                     data-id="<?php echo $value['id']; ?>">
                    Activate
                  </a>
                <?php } else { ?>
                  <button type="button"
                      class="btn btn-danger btn-deactivate"
                      style="font-size:11px;"
                      data-id="<?php echo $value['id']; ?>">
                    Deactivate
                  </button>
                <?php } ?>
              </td>

              <!-- ===== CIN / REGISTRATION MODE TOGGLE ===== -->
              <td>
                <div class="sw-wrap">
                  <label class="toggle" aria-label="CIN mode for <?php echo $value['school_name']; ?>">
                    <input
                        type="checkbox"
                        <?php echo $regOnline ? 'checked' : ''; ?>
                        data-school-code="<?php echo $value['school_code']; ?>"
                        onchange="toggleCinMode(<?php echo $value['id']; ?>, this)">
                    <span class="slider"></span>
                  </label>
                  <span class="sw-lbl" id="cin-lbl-<?php echo $value['id']; ?>">
                    <?php echo $regOnline ? 'Online' : 'Offline'; ?>
                  </span>
                </div>
              </td>

              <!-- ===== COMPETITION MODE TOGGLE ===== -->
              <td>
                <div class="sw-wrap">
                  <label class="toggle" aria-label="Competition mode for <?php echo $value['school_name']; ?>">
                    <input
                      type="checkbox"
                      <?php echo $isOnline ? 'checked' : ''; ?>
                      data-school-code="<?php echo $value['school_code']; ?>"
                      onchange="toggleCompetitionMode(<?php echo $value['id']; ?>, this)">
                    <span class="slider"></span>
                  </label>
                  <span class="sw-lbl" id="comp-lbl-<?php echo $value['id']; ?>">
                    <?php echo $isOnline ? 'Online' : 'Offline'; ?>
                  </span>
                </div>
              </td>

              <!-- Details -->
              <td>
                <!--<a href="<?php echo base_url(); ?>manage/franchise/schoolaccees/<?php echo $value['id']; ?>"-->
                <!--   class="btn btn-primary" style="font-size:11px;">View &amp; Edit</a>-->
                <a href="javascript:void(0);"
                   class="btn btn-primary btn-edit"
                   style="font-size:11px;"
                   data-id="<?php echo $value['id']; ?>">
                   View &amp; Edit
                </a>
              </td>

              <!-- Delete -->
              <td>
                <a class="btn btn-danger" style="font-size:11px;"
                   onclick="return confirm('Are you sure you want to delete this school?');"
                   href="<?php echo SITE_URL; ?>franchise/adminSchooldelete/<?php echo $value['id']; ?>">
                  Delete
                </a>
              </td>

            </tr>
          <?php $i++; } ?>
          </tbody>
        </table>
        </div>

      <?php } else { ?>
        <div style="text-align:center;"><h3>No School Found ...</h3></div>
      <?php } ?>

    </div><!-- /.box-content -->
  </div><!-- /.box -->
</div>

<?php include('footer.php'); ?>

<!-- ===== ACTIVATE MODAL ===== -->
<div id="activateModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:9999; align-items:center; justify-content:center;">
  <div style="background:#fff; border-radius:10px; padding:28px 32px; box-shadow:0 8px 32px rgba(0,0,0,.18); overflow-y:auto;">
    <form id="activateForm">

      <h4 style="margin:0 0 12px; font-size:16px; color:#1a1a1a;">Select Products to Activate</h4>
      <input type="hidden" id="activate_school_id" name="school_id" value="">

      <!-- Column header row -->
      <div style="display:flex; align-items:center; margin-bottom:6px; padding:0 4px;">
        <div style="width:70%; display:flex;">
          <div style="width:40%; font-size:12px; font-weight:600; color:#555;">
            <input type="checkbox" id="checkAll"> Select All
          </div>
          <div style="width:30%; font-size:12px; font-weight:600; color:#555; text-align:center;">Price Code</div>
          <div style="width:30%; font-size:12px; font-weight:600; color:#555; text-align:center;">Level</div>
        </div>
        <div style="width:30%; font-size:12px; font-weight:600; color:#555; text-align:center; margin-left:10px;">Value</div>
      </div>

      <div style="display:flex; align-items:flex-start; gap:10px;">

        <!-- Left: product list -->
        <div style="width:70%;">
          <div id="productList" style="max-height:420px; border:1px solid #eee; overflow-y:auto; border-radius:6px; padding:8px;">
            <?php
              $this->db->select('*');
              $this->db->from('products');
              $this->db->where('status', 'Active');
              $this->db->where('product_name !=', 'Lunar Skill Test');
              $res = $this->db->get();
              $result = $res->result_array();

              $this->db->select('*');
              $this->db->from('price_codegenration');
              $res2 = $this->db->get();
              $result2 = $res2->result_array();

              /* ── Fetch levels per product from competition_level_byproduct ── */
              $lvRes = $this->db
                            ->select('level_id, level_name, product_id')
                            ->order_by('medal_no', 'ASC')
                            ->get('competition_level_byproduct')
                            ->result_array();

              /* Build a map: product_id => [ [level_id, level_name], ... ] */
              $levelsByProduct = [];
              foreach ($lvRes as $lv) {
                  $levelsByProduct[$lv['product_id']][] = [
                      'level_id'   => $lv['level_id'],
                      'level_name' => $lv['level_name'],
                  ];
              }

              if (!empty($result)) {
                foreach ($result as $val) { ?>
                <div class="product-row" id="prow-<?php echo $val['product_id']; ?>">

                  <!-- Checkbox + product name -->
                  <label class="col-check" style="width:40%; display:flex; align-items:center; gap:6px; cursor:pointer; margin:0;">
                    <input type="checkbox"
                           name="product_id[]"
                           value="<?php echo $val['product_id']; ?>"
                           data-product-name="<?php echo htmlspecialchars($val['product_name'], ENT_QUOTES); ?>"
                           onchange="rebuildLevelDropdown(<?php echo $val['product_id']; ?>); refreshSummary()">
                    <span style="font-size:13px; color:#333;"><?php echo $val['product_name']; ?></span>
                  </label>

                  <!-- Price Code -->
                  <div class="col-price" style="width:30%; padding-right:4px;">
                    <?php if (!empty($result2)) { ?>
                    <select name="product_price[<?php echo $val['product_id']; ?>]"
                            id="product_p_<?php echo $val['product_id']; ?>"
                            class="chk"
                            onchange="handlePriceCodeChange(); refreshSummary();">
                      <option value="">-- Price --</option>
                      <?php foreach ($result2 as $price) { ?>
                      <option value="<?php echo $price['price_code']; ?>"><?php echo $price['price_code']; ?></option>
                      <?php } ?>
                    </select>
                    <?php } ?>
                  </div>

                  <!-- Level — options come from competition_level_byproduct filtered by product_id -->
                  <div class="col-level" style="width:30%;">
                    <select name="product_level[<?php echo $val['product_id']; ?>]"
                            id="product_l_<?php echo $val['product_id']; ?>"
                            class="chk"
                            onchange="refreshSummary()">
                      <option value="">-- Level --</option>
                      <?php if (!empty($levelsByProduct[$val['product_id']])) { ?>
                        <option value="All">All Levels</option>
                        <?php foreach ($levelsByProduct[$val['product_id']] as $lv) { ?>
                        <option value="<?php echo $lv['level_id']; ?>"><?php echo htmlspecialchars($lv['level_name']); ?></option>
                        <?php } ?>
                      <?php } else { ?>
                        <option value="" disabled style="color:#bbb;">No levels</option>
                      <?php } ?>
                    </select>
                  </div>

                </div>
              <?php } } ?>
          </div><!-- /#productList -->

          <!-- ===== SELECTED PRODUCTS SUMMARY ===== -->
          <div id="selectedSummary">
            <div class="sum-title">Selected Products</div>
            <div class="sum-empty" id="sum-empty-msg">No products selected yet.</div>
            <div class="sum-list" id="sum-list"></div>
          </div>

        </div><!-- /left col -->

        <!-- Right: value fields -->
        <div class="promo-right-col" style="width:30%; max-height:500px; overflow-y:auto; border-radius:6px; padding:8px; display:flex; flex-direction:column; gap:4px;">
          <label style="font-size:11px; font-weight:600; color:#555;">School Amount Fixed <span style="color:red;">*</span></label>
          <input type="text" name="schoolper" class="chk" required style="width:96%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">

          <label style="font-size:11px; font-weight:600; color:#555;">Management Percentage <span style="color:red;">*</span></label>
          <select name="manageper" class="chk" required style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
            <option value="">-- select management % --</option>
            <option value="2">2%</option><option value="3">3%</option><option value="4">4%</option>
            <option value="5">5%</option><option value="8">8%</option><option value="10">10%</option>
            <option value="12">12%</option><option value="15">15%</option><option value="16">16%</option>
            <option value="18">18%</option><option value="20">20%</option><option value="22">22%</option>
          </select>

          <label style="font-size:11px; font-weight:600; color:#555;">Aviansys Percentage <span style="color:red;">*</span></label>
          <select name="com_peravian" class="chk" required style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
            <option value="">-- select aviansys % --</option>
            <option value="2">2%</option><option value="3">3%</option><option value="4">4%</option>
            <option value="5">5%</option><option value="8">8%</option><option value="10">10%</option>
            <option value="12">12%</option><option value="15">15%</option><option value="16">16%</option>
            <option value="18">18%</option><option value="20">20%</option><option value="22">22%</option>
            <option value="25">25%</option><option value="30">30%</option>
          </select>

          <label style="font-size:11px; font-weight:600; color:#555;">Associate Percentage</label>
          <select name="associate_per" class="chk" style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
            <option value="">-- select associate % --</option>
            <option value="5">5%</option><option value="10">10%</option><option value="15">15%</option>
            <option value="20">20%</option><option value="25">25%</option><option value="30">30%</option>
            <option value="35">35%</option><option value="40">40%</option><option value="45">45%</option>
            <option value="50">50%</option><option value="55">55%</option><option value="60">60%</option>
          </select>

          <label style="font-size:11px; font-weight:600; color:#555;">Franchise Percentage</label>
          <select name="com_per" class="chk" style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
            <option value="">-- select franchise % --</option>
            <option value="5">5%</option><option value="10">10%</option><option value="15">15%</option>
            <option value="20">20%</option><option value="25">25%</option><option value="30">30%</option>
            <option value="35">35%</option><option value="40">40%</option><option value="45">45%</option>
            <option value="50">50%</option><option value="55">55%</option><option value="60">60%</option>
          </select>

          <label style="font-size:11px; font-weight:600; color:#555;">CRM % <span style="color:red;">*</span></label>
          <select name="crm_per" class="chk" style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
            <option value="0" selected>0%</option>
            <option value="1">1%</option><option value="2">2%</option><option value="3">3%</option>
            <option value="4">4%</option><option value="5">5%</option><option value="6">6%</option>
            <option value="7">7%</option><option value="8">8%</option><option value="9">9%</option>
            <option value="10">10%</option>
          </select>

          <label style="font-size:11px; font-weight:600; color:#555;">Free Material Royalty <span style="color:red;">*</span></label>
          <input type="text" name="free_mat_royalty" placeholder="Enter royalty" class="chk"
                 style="width:100%; border:1px solid #ccc; border-radius:5px; font-size:12px; color:#333;">
        </div>

      </div><!-- /flex row -->

      <div id="activate_error" style="display:none; color:#c0392b; font-size:12px; margin-top:10px; padding:6px 10px; background:#fdecea; border-radius:5px;"></div>

      <div style="display:flex; gap:10px; justify-content:flex-end; margin-top:20px;">
        <button type="button" onclick="closeActivateModal()"
                style="padding:8px 20px; border-radius:6px; border:1px solid #ccc; background:#f1efe8; cursor:pointer; font-size:13px;">
          Cancel
        </button>
        <button type="button" id="confirmActivateBtn" onclick="submitActivateForm()"
                style="padding:8px 20px; border-radius:6px; border:none; background:#1D9E75; color:#fff; cursor:pointer; font-size:13px; font-weight:600;">
          Confirm Activate
        </button>
      </div>

    </form>
  </div>
</div>
<!-- ===== END ACTIVATE MODAL ===== -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>/* ==============================================
   EDIT — reuses the activate modal
   ============================================== */
$(document).on('click', '.btn-edit', function() {
    var schoolId = $(this).data('id');

    // Change modal title and button to edit mode
    document.querySelector('#activateModal h4').textContent = 'Edit School Activation';
    document.getElementById('confirmActivateBtn').textContent = 'Save Changes';

    openActivateModal(schoolId);
});

// Patch: when modal closes, restore activate mode defaults
var _originalCloseActivateModal = closeActivateModal;
closeActivateModal = function() {
    document.querySelector('#activateModal h4').textContent = 'Select Products to Activate';
    document.getElementById('confirmActivateBtn').textContent = 'Confirm Activate';
    _originalCloseActivateModal();
};</script>

<script>

/* ==============================================
   LEVELS MAP  (product_id → array of {level_id, level_name})
   Built from competition_level_byproduct, ordered by medal_no
   ============================================== */
var levelsByProduct = <?php echo json_encode($levelsByProduct, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

/* ==============================================
   HELPERS
   ============================================== */
function showFlash(message, type) {
    var bg    = type === 'success' ? '#d4edda' : '#f8d7da';
    var color = type === 'success' ? '#155724' : '#721c24';
    var el    = document.getElementById('flash-message');
    el.style.background = bg;
    el.style.color      = color;
    el.textContent      = message;
    el.style.display    = 'block';
    setTimeout(function(){ el.style.display = 'none'; }, 4000);
}


/* ==============================================
   REBUILD LEVEL DROPDOWN FOR A PRODUCT
   Called whenever a product checkbox changes so
   the level <select> always reflects that product's
   entries from competition_level_byproduct.
   ============================================== */
function rebuildLevelDropdown(pid, savedValue) {
    var sel = document.getElementById('product_l_' + pid);
    if (!sel) return;

    var levels = levelsByProduct[pid] || [];

    // Clear and rebuild
    sel.innerHTML = '<option value="">-- Level --</option>';

    if (levels.length === 0) {
        var noOpt = document.createElement('option');
        noOpt.value    = '';
        noOpt.disabled = true;
        noOpt.style.color = '#bbb';
        noOpt.textContent = 'No levels';
        sel.appendChild(noOpt);
        return;
    }

    var allOpt = document.createElement('option');
    allOpt.value       = 'All';
    allOpt.textContent = 'All Levels';
    sel.appendChild(allOpt);

    levels.forEach(function(lv) {
        var opt = document.createElement('option');
        opt.value       = lv.level_id;
        opt.textContent = lv.level_name;
        sel.appendChild(opt);
    });

    if (savedValue) sel.value = savedValue;
}



function refreshSummary() {
    var list    = document.getElementById('sum-list');
    var empty   = document.getElementById('sum-empty-msg');
    var checked = document.querySelectorAll('input[name="product_id[]"]:checked');

    list.innerHTML = '';

    if (checked.length === 0) {
        empty.style.display = '';
        return;
    }
    empty.style.display = 'none';

    checked.forEach(function(cb) {
        var pid   = cb.value;
        var name  = cb.dataset.productName || ('Product ' + pid);
        var price = '';
        var level = '';

        var priceEl = document.getElementById('product_p_' + pid);
        if (priceEl && priceEl.value) {
            price = priceEl.value;
        }

        var levelEl = document.getElementById('product_l_' + pid);
        if (levelEl && levelEl.value) {
            level = levelEl.options[levelEl.selectedIndex].text;
        }

        var tag = document.createElement('div');
        tag.className = 'sum-tag';

        var html = '<strong>' + name + '</strong>';
        if (price) html += ' <span class="sum-meta">· ' + price + '</span>';
        if (level) html += ' <span class="sum-meta">· ' + level + '</span>';
        tag.innerHTML = html;

        list.appendChild(tag);
    });
}


/* ==============================================
   COMPETITION MODE TOGGLE
   ============================================== */
var _cm_schoolId = null;
var _cm_checkbox = null;

function toggleCompetitionMode(schoolId, chk) {
    _cm_schoolId = schoolId;
    _cm_checkbox = chk;

    if (!chk.checked) {
        $.ajax({
            url:      "<?php echo base_url(); ?>manage/ajax/updateCompetitionMode",
            type:     'POST',
            dataType: 'json',
            data:     { school_id: schoolId, mode: 'offline' },
            success: function(res) {
                if (res.status === 'success') {
                    document.getElementById('comp-lbl-' + schoolId).textContent = 'Offline';
                    showFlash('Competition mode set to Offline.', 'success');
                } else {
                    alert('Failed to save. Please try again.');
                    chk.checked = true;
                }
            },
            error: function() {
                alert('Server error. Please try again.');
                chk.checked = true;
            }
        });
        return;
    }

    document.getElementById('cm_start_date').value = '';
    document.getElementById('cm_end_date').value   = '';
    var errEl = document.getElementById('cm_error');
    errEl.style.display = 'none';
    errEl.textContent   = '';
    document.getElementById('compModeModal').classList.add('show');
}

function saveCompMode() {
    var errEl     = document.getElementById('cm_error');
    var startDate = document.getElementById('cm_start_date').value.trim();
    var endDate   = document.getElementById('cm_end_date').value.trim();
    errEl.style.display = 'none';

    if (!startDate || !endDate) {
        errEl.textContent   = 'Start date and end date are required.';
        errEl.style.display = 'block';
        return;
    }
    if (endDate < startDate) {
        errEl.textContent   = 'End date cannot be before start date.';
        errEl.style.display = 'block';
        return;
    }

    document.getElementById('compModeModal').classList.remove('show');

    $.ajax({
        url:      "<?php echo base_url(); ?>manage/ajax/updateCompetitionMode",
        type:     'POST',
        dataType: 'json',
        data:     { school_id: _cm_schoolId, mode: 'online', start_date: startDate, end_date: endDate },
        success: function(res) {
            if (res.status === 'success') {
                document.getElementById('comp-lbl-' + _cm_schoolId).textContent = 'Online';
                showFlash('Competition mode set to Online.', 'success');
            } else {
                alert('Failed to save. Please try again.');
                _cm_checkbox.checked = false;
            }
        },
        error: function() {
            alert('Server error. Please try again.');
            _cm_checkbox.checked = false;
        }
    });
}

function cancelCompMode() {
    _cm_checkbox.checked = false;
    document.getElementById('compModeModal').classList.remove('show');
}

document.getElementById('compModeModal').addEventListener('click', function(e) {
    if (e.target === this) { cancelCompMode(); }
});


/* ==============================================
   CIN MODE TOGGLE
   ============================================== */
/* ==============================================
   CIN MODE TOGGLE
   ============================================== */
var _cin_schoolId   = null;
var _cin_checkbox   = null;
var _cin_schoolCode = null;

function toggleCinMode(schoolId, chk) {
    _cin_schoolId   = schoolId;
    _cin_checkbox   = chk;
    _cin_schoolCode = chk.dataset.schoolCode;

    if (!chk.checked) {
        // Directly set to offline without popup
        $.ajax({
            url:      "<?php echo base_url(); ?>manage/ajax/updateCinMode",
            type:     'POST',
            dataType: 'json',
            data:     { school_id: _cin_schoolId, mode: 'offline' },
            success: function(res) {
                if (res.status === 'success') {
                    document.getElementById('cin-lbl-' + _cin_schoolId).textContent = 'Offline';
                    showFlash('CIN mode set to Offline.', 'success');
                } else {
                    alert('Failed to save. Please try again.');
                    _cin_checkbox.checked = true;
                }
            },
            error: function() {
                alert('Server error. Please try again.');
                _cin_checkbox.checked = true;
            }
        });
        return;
    }

    document.getElementById('cin_start_date').value = '';
    document.getElementById('cin_end_date').value   = '';
    var errEl = document.getElementById('cin_error');
    errEl.style.display = 'none';
    errEl.textContent   = '';
    document.getElementById('cinModeModal').classList.add('show');
}

function saveCinMode() {
    var errEl     = document.getElementById('cin_error');
    var startDate = document.getElementById('cin_start_date').value.trim();
    var endDate   = document.getElementById('cin_end_date').value.trim();
    errEl.style.display = 'none';

    if (!startDate || !endDate) {
        errEl.textContent   = 'Start date and end date are required.';
        errEl.style.display = 'block';
        return;
    }
    if (endDate < startDate) {
        errEl.textContent   = 'End date cannot be before start date.';
        errEl.style.display = 'block';
        return;
    }

    document.getElementById('cinModeModal').classList.remove('show');

    $.ajax({
        url:      "<?php echo base_url(); ?>manage/ajax/updateCinMode",
        type:     'POST',
        dataType: 'json',
        data:     { school_id: _cin_schoolId, mode: 'online', start_date: startDate, end_date: endDate },
        success: function(res) {
            if (res.status === 'success') {
                document.getElementById('cin-lbl-' + _cin_schoolId).textContent = 'Online';
                showFlash('CIN mode set to Online.', 'success');
            } else {
                alert('Failed to save. Please try again.');
                _cin_checkbox.checked = false;
            }
        },
        error: function() {
            alert('Server error. Please try again.');
            _cin_checkbox.checked = false;
        }
    });
}

function cancelCinMode() {
    _cin_checkbox.checked = false;
    document.getElementById('cinModeModal').classList.remove('show');
}

document.getElementById('cinModeModal').addEventListener('click', function(e) {
    if (e.target === this) { cancelCinMode(); }
});


/* ==============================================
   SCHOOL DEACTIVATION
   ============================================== */
$(document).on('click', '.btn-deactivate', function() {
    if (!confirm('Are you sure you want to deactivate this school?')) return;

    var schoolId = $(this).data('id');
    var btn      = $(this);
    btn.prop('disabled', true).text('Saving...');

    $.ajax({
        url:      "<?php echo base_url(); ?>manage/franchise/schoollevelactive/" + schoolId,
        type:     'POST',
        dataType: 'json',
        success: function(res) {
            if (res && res.status === 'success') {
                swapActivationCell(schoolId, false);
                showFlash(res.message || 'School deactivated successfully.', 'success');
            } else {
                btn.prop('disabled', false).text('Deactivate');
                showFlash((res && res.message) ? res.message : 'Failed to deactivate. Please try again.', 'error');
            }
        },
        error: function(xhr) {
            btn.prop('disabled', false).text('Deactivate');
            if (xhr.status === 200) {
                swapActivationCell(schoolId, false);
                showFlash('School deactivated successfully.', 'success');
                 setCinOffline(schoolId);
            } else {
                showFlash('Server error. Please try again.', 'error');
            }
        }
    });
});

/* ==============================================
   SET CIN MODE TO OFFLINE (reusable helper)
   ============================================== */
function setCinOffline(schoolId) {
    $.ajax({
        url:      "<?php echo base_url(); ?>manage/ajax/updateCinMode",
        type:     'POST',
        dataType: 'json',
        data:     { school_id: schoolId, mode: 'offline' },
        success: function(res) {
            if (res.status === 'success') {
                // Update toggle checkbox to unchecked
                var row = document.getElementById('school-row-' + schoolId);
                if (row) {
                    var cinChk = row.querySelector('input[onchange*="toggleCinMode"]');
                    if (cinChk) cinChk.checked = false;
                }
                // Update label
                var lbl = document.getElementById('cin-lbl-' + schoolId);
                if (lbl) lbl.textContent = 'Offline';
            }
        }
    });
}

function swapActivationCell(schoolId, activate) {
    var row  = document.getElementById('school-row-' + schoolId);
    if (!row) return;
    var cell = row.querySelector('td:nth-child(9)');
    if (!cell) return;
    if (activate) {
        cell.innerHTML = '<button type="button" class="btn btn-danger btn-deactivate" style="font-size:11px;" data-id="' + schoolId + '">Deactivate</button>';
    } else {
        cell.innerHTML = '<a href="javascript:void(0);" class="btn btn-warning btn-activate" style="font-size:11px;" data-id="' + schoolId + '">Activate</a>';
    }
}


/* ==============================================
   PRICE CODE → DISABLE FIELDS ON "promotional-0"
   ============================================== */
function handlePriceCodeChange(changedSel) {
    var promoSelect = null;

    document.querySelectorAll('select[id^="product_p_"]').forEach(function(sel) {
        if (sel.value === 'promotional-0') promoSelect = sel;
    });

    var isPromo = !!promoSelect;

    // Force every other product's price dropdown to match "promotional-0"
    document.querySelectorAll('select[id^="product_p_"]').forEach(function(sel) {
        if (isPromo) {
            if (sel.value !== 'promotional-0') {
                sel.value = 'promotional-0';
            }
            sel.disabled = (sel !== promoSelect); // lock all but the one user just changed
        } else {
            sel.disabled = false;
        }
    });

    // Existing: hide/show the common value fields when promo is active
    var fields = document.querySelectorAll(
        'select[name="manageper"], select[name="com_peravian"], select[name="associate_per"], ' +
        'select[name="com_per"], select[name="crm_per"], input[name="free_mat_royalty"], input[name="schoolper"]'
    );

    fields.forEach(function(field) {
        field.style.display = isPromo ? 'none' : '';
        field.value = isPromo ? '' : field.value;
        var lbl = field.previousElementSibling;
        if (lbl && lbl.tagName === 'LABEL') {
            lbl.style.display = isPromo ? 'none' : '';
        }
    });

    refreshSummary();
}
document.getElementById('productList').addEventListener('change', function(e) {
    if (e.target && e.target.id && e.target.id.startsWith('product_p_')) {
        handlePriceCodeChange();
    }
});


/* ==============================================
   ACTIVATE MODAL
   ============================================== */
$(document).on('click', '.btn-activate', function() {
    openActivateModal($(this).data('id'));
});

function openActivateModal(schoolId) {
    document.getElementById('activate_school_id').value = schoolId;
    document.getElementById('activate_error').style.display = 'none';
    document.getElementById('activate_error').textContent   = '';

    // Reset all fields
    document.getElementById('checkAll').checked = false;
    document.querySelectorAll('input[name="product_id[]"]').forEach(cb => cb.checked = false);
    document.querySelectorAll('#activateForm select').forEach(sel => sel.selectedIndex = 0);
    document.querySelectorAll('#activateForm input[type="text"]').forEach(inp => inp.value = '');

    // Reset level dropdowns explicitly — rebuild from levelsByProduct map
    document.querySelectorAll('select[id^="product_l_"]').forEach(function(sel) {
        var pid = sel.id.replace('product_l_', '');
        rebuildLevelDropdown(pid, '');
    });

    // Show all value fields (in case promo hid them)
    document.querySelectorAll(
        'select[name="manageper"], select[name="com_peravian"], select[name="associate_per"], ' +
        'select[name="com_per"], select[name="crm_per"], input[name="free_mat_royalty"], input[name="schoolper"]'
    ).forEach(function(f) {
        f.style.display = '';
        f.value = '';
        var lbl = f.previousElementSibling;
        if (lbl && lbl.tagName === 'LABEL') lbl.style.display = '';
    });

    // Reset summary
    refreshSummary();

    // Show modal
    document.getElementById('activateModal').style.display = 'flex';

    // ── Fetch existing saved data and pre-fill ──────────────────
    $.ajax({
        url:      "<?php echo base_url(); ?>manage/franchise/getSchoolActivationData",
        type:     'POST',
        dataType: 'json',
        data:     { school_id: schoolId },
        success: function(res) {
            if (!res || res.status !== 'success') return;

            var c = res.common;

            // Fill common value fields
            document.querySelector('input[name="schoolper"]').value         = c.school_amount    || '';
            document.querySelector('select[name="manageper"]').value        = c.manageper        || '';
            document.querySelector('select[name="com_peravian"]').value     = c.com_peravian     || '';
            document.querySelector('select[name="associate_per"]').value    = c.associate_per    || '';
            document.querySelector('select[name="com_per"]').value          = c.franchise_per    || '';
            document.querySelector('select[name="crm_per"]').value          = c.crm_per          || '';
            document.querySelector('input[name="free_mat_royalty"]').value  = c.free_mat_royalty || '';

            // Pre-fill checked products, price codes, and levels
            // Backend should return:
            //   res.product_ids  → array of product_id strings
            //   res.pricecode_ids → object keyed by product_id  e.g. { "3": "standard-A" }
            //   res.level_ids    → object keyed by product_id  e.g. { "3": "2" }
            res.product_ids.forEach(function(pid) {
                var cb = document.querySelector('input[name="product_id[]"][value="' + pid + '"]');
                if (cb) cb.checked = true;

                var priceCode = (res.pricecode_ids && res.pricecode_ids[pid]) ? res.pricecode_ids[pid] : '';
                var priceEl   = document.getElementById('product_p_' + pid);
                if (priceEl && priceCode) priceEl.value = priceCode;

                var savedLevel = (res.level_ids && res.level_ids[pid]) ? res.level_ids[pid] : '';
                rebuildLevelDropdown(pid, savedLevel);
            });

            // Update Select All checkbox state
            var allBoxes   = document.querySelectorAll('input[name="product_id[]"]');
            var allChecked = document.querySelectorAll('input[name="product_id[]"]:checked');
            document.getElementById('checkAll').checked = (allBoxes.length === allChecked.length);

            // Refresh summary with pre-filled data
            refreshSummary();
        }
    });
}

function closeActivateModal() {
    document.getElementById('activateModal').style.display = 'none';
}

document.getElementById('activateModal').addEventListener('click', function(e) {
    if (e.target === this) { closeActivateModal(); }
});

document.getElementById('checkAll').addEventListener('change', function() {
    document.querySelectorAll('input[name="product_id[]"]').forEach(function(cb) {
        cb.checked = document.getElementById('checkAll').checked;
    });
    refreshSummary();
});

function submitActivateForm() {
    var errEl   = document.getElementById('activate_error');
    var btnEl   = document.getElementById('confirmActivateBtn');
    var checked = document.querySelectorAll('input[name="product_id[]"]:checked');

    errEl.style.display = 'none';
    errEl.textContent   = '';

    if (checked.length === 0) {
        errEl.textContent   = 'Please select at least one product.';
        errEl.style.display = 'block';
        return;
    }

    // FormData picks up product_price[pid] and product_level[pid] automatically
    var formData = new FormData(document.getElementById('activateForm'));

    btnEl.disabled    = true;
    btnEl.textContent = 'Saving...';

    $.ajax({
        url:         "<?php echo base_url(); ?>manage/franchise/newschoollevelactive",
        type:        'POST',
        dataType:    'json',
        data:        formData,
        processData: false,
        contentType: false,
        success: function(res) {
            btnEl.disabled    = false;
            btnEl.textContent = 'Confirm Activate';

            if (res && res.status === 'success') {
                var schoolId = document.getElementById('activate_school_id').value;
                closeActivateModal();
                swapActivationCell(schoolId, true);
                showFlash(res.message || 'School activated successfully.', 'success');
            } else {
                errEl.textContent   = (res && res.message) ? res.message : 'Something went wrong. Please try again.';
                errEl.style.display = 'block';
            }
        },
        error: function(xhr) {
            btnEl.disabled    = false;
            btnEl.textContent = 'Confirm Activate';

            if (xhr.status === 200) {
                var schoolId = document.getElementById('activate_school_id').value;
                closeActivateModal();
                swapActivationCell(schoolId, true);
                showFlash('School activated successfully.', 'success');
            } else {
                errEl.textContent   = 'Server error (' + xhr.status + '). Please try again.';
                errEl.style.display = 'block';
            }
        }
    });
}


/* ==============================================
   CASCADE DROPDOWNS
   ============================================== */
$("#state_id").change(function(){
    $.ajax({
        url:  "<?php echo base_url(); ?>manage/ajax/franchiseList",
        data: { state_id: this.value },
        type: 'post',
        success: function(result){ $("#franchise").html(result); }
    });
});

$("#franchise").change(function(){
    $.ajax({
        url:  "<?php echo base_url(); ?>manage/ajax/AreaCode/",
        data: { franchise_id: this.value },
        type: 'post',
        success: function(result){ $("#area").html(result); }
    });
});

</script>
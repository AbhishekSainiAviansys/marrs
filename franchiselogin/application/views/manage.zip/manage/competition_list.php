<?php include('header.php');
$dateParts = explode(' ', $result['competition_date']);
$date = $dateParts[0]; 

//print_r($arr);
?>


			
			<div class="row-fluid sortable">
			
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h1><small>Active Competition List</small></h1>
					</div>
					<div class="box-content">
						
							<fieldset>
							
                         
		                    <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1"> 
		                    <div class="form-actions ">
			                        <table  cellpadding="5px" width='100%'>
                             <tbody>
                                 
                             
							        
							        <tr>
							    <td class=''>
							        <label>Country</label>
							        <select name="country" id="country" style="width: 220px;"  >
							            <option>select Country </option>
                                    <option value='105' <?php if($result['country']=='105'){echo 'selected';} ?> >INDIA </option>
                                    
                                     <?php
                                     
                                     $query = $this->db->query("SELECT * FROM countries;"); 
                                    
                                     foreach ($query->result() as $row)
                                    {
                                    echo "<option value='{$row->country_id}'    > {$row->country_name}</option>";
                                    }
                                    
                                    ?>
                                </select>
							    </td>     
							      <td class=''>
							        <label>State</label>
							        <select name="state" id="state" style="width: 220px;" >
                                    <!--<option value='All'>All Class</option>-->
                                     
                                     <?php
                                     
                                    //  $query = $this->db->query("SELECT * FROM `states` where country_id='105';");
                                       
                                     foreach ($stateload as $row)
                                    {
                                    //echo "<option value='{$row["state_subdivision_id"]}'>{$row["state_subdivision_name"]}</option>";
                                    echo "<option value='{$row["state_subdivision_id"]}'";
                                    if ($result['state'] == $row['state_subdivision_id']) 
                                    {
                                        echo " selected='selected'";
                                    }
                                        echo ">{$row["state_subdivision_name"]}</option>";
                                    }
                                    
                                    ?>
                                </select>
							    </td>
							    <td class=''>
							        <label>Period</label>
							        <select name="period" id="period" style="width: 220px;"  >
                                    <option style='display:none;'>Select period</option>
                                    
                                     <?php
                                     
                                     $query = $this->db->query("SELECT * FROM `period`;");
                                    
                                     foreach ($periodload as $row)
                                    {
                                    //echo "<option value='{$row->period_id}'>{$row->period_id} - {$row->period_name}</option>";
                                    echo "<option value='{$row["period_id"]}'";
                                    if ($result['period'] == $row['period_id']) {
                                        echo " selected='selected'";
                                    }
                                    echo ">{$row["period_name"]}</option>";
                                    }
                                    
                                    ?>
                                </select>
							    </td>
							    <td class=''>
							        <label>Product</label>
							        <select name="product_id" id="product" style="width: 220px;"  >
                                    <option value=''>-- Select product --</option>
                                    
                                     <?php
                                     
                                     $query = $this->db->query("SELECT * FROM products where status='Active' ORDER BY product_name");
                                    
                                     foreach ($productload as $row)
                                    {
                                    //echo "<option value='{$row->product_name}'>{$row->product_name}</option>";
                                    
                                    echo "<option value='{$row["product_name"]}'";
                                    if ($result['product_id'] == $row['product_name']) {
                                        echo " selected='selected'";
                                    }
                                    echo ">{$row["product_name"]}</option>";
                                    }
                                    
                                    ?>
                                </select>
							    </td>
							    <td class=''>
							        <label>Level</label>
							        <select name="clevel" id="level" style="width: 220px;"  >
                                    <option style='display:none;'>Select level</option>
                                    
                                     <?php
                                     
                                     $query = $this->db->query("SELECT * FROM `competition_levels`;");
                                    
                                     foreach ($levelload as $row)
                                    {
                                    // echo "<option value='{$row->id}'>{$row->id} - {$row->level_name}</option>";
                                    
                                    echo "<option value='{$row["level_id"]}'";
                                    if ($result['clevel'] == $row['level_id']) {
                                        echo " selected='selected'";
                                    }
                                    echo ">{$row["level_name"]}</option>";

                                    }
                                    
                                    ?>
                                </select>
							    </td>
							    </tr>
							      <tr>
								<button type="submit" class="btn btn-primary" id="submit" name="search" >Search</button>
								<!--<button class="btn">Cancel</button>-->
								</tr>
							  
						</tbody>
					            	</table>
					            </div>
						
						          <table class="table table-bordered">
						            <thead>
							  
						                  <tr>
						                      <!--<th>Revenue</th>-->
						                      <th>Sr. No</th>
						                      <th>Schedule Id</th>
						                      <th>Product</th>
						                      <th>Competition Level</th>
						                      <th>Period</th>
						                      <th>State</th>
						                      <th>Active Parts</th>
						                      <!--<th>Status</th>-->
						                      <th>Status</th>
						                      <th>Mock Orientation Closing Details</th>
						                      <th>Exam Centers</th>
						                      
						                  </tr>
						              </thead>
						          
						          <?php 
						          $i=1;
						          foreach($arr as $row){ 
						              
						          $revenue_setting=array();
						          
						          if(!empty($row['revenue_setting_id'])){    
						            $revenue_setting = $this->db->get_where('revenue_setting',array('id'=>$row['revenue_setting_id']))->row_array();
						          }
						          
						          
						          
						          ?>
						          <tr>
						              <!--<td><?php //print_r($revenue_setting);?></td>-->
						            <td><?php echo $i; ?></td>
						            <td><?php echo $row['id']; ?></td>
						            <td><?php echo $row['product_name']; ?></td>
						            <td>
						                <?php
        						                $stat = $this->db->get_where('competition_level_byproduct',array('level_id'=>$row['clevel'],'product_name'=>$row['product_name']))->row();
        						                echo $stat->level_name;
    						                 
						                        $center = $this->db->get_where('exam_centers',array('comp_id'=>$row['id']))->result();
						                      //  echo $this->db->last_query();
						                        if(!empty($center)){  
						                        foreach($center as $cen){ 
						                   ?>
						                      <h5 style='padding-top:10px;'><?php echo $cen->center_name;  ?></h5> <br>
						                  <?php }    
						                   }
						                ?> 
						            
						            </td>
						            <td><?php
						            $stat = $this->db->get_where('period',array('period_id'=>$row['period_id']))->row();
						                echo $stat->academic_year;
						            //echo $row['academic_year'];
						            
						            ?>
						            
						            
						            </td>
						            <td>
						                <?php 
    						                $stat = $this->db->get_where('states',array('state_subdivision_id'=>$row['state_id']))->row();
    						                echo $stat->state_subdivision_name;
    						                echo '<br><br>Currently is active in all areas.<br><br>'; 
    						                if($row['franchise_split']=='yes')
    						                {    
    						                    echo  'Franchise Split : '.$row['com_per'].$revenue_setting['com_per'].'%';echo '<br>'; 
    						                   
    						                }
                                            if($row['aviansys_split']=='yes')
                                            {    
                                                if(!empty($revenue_setting['com_peravian'])){
                                                    echo  'Aviansys Split : '.$revenue_setting['com_peravian'].'%';echo '<br>';
                                                }else{
                                                    echo  'Aviansys Split : '.$row['com_peravian'].'%';echo '<br>';
                                                }
                                            }
                                            if(!empty($revenue_setting['manageper'])){
                                                echo  'Management : '.$revenue_setting['manageper'].'%';echo '<br>';
                                            }else{
                                                echo  'Management : '.$row['manageper'].'%';echo '<br>'; 
                                            }   
                                               
                                            if($row['franchise_split']=='no'){$rr=0;}else{$rr=$row['com_per'].$revenue_setting['com_per'];}
                                            echo  'Franchise Split : '.$row['franchise_split'].$revenue_setting['franchise_split'].' = '.$rr.'%';echo '<br>'; 
                                            
                                            
                                            if($row['associate_split']=='no'){$rr=0;}else{$rr=$row['associate_per'].$revenue_setting['associate_per'];}
                                            
                                            
                                            echo  'Associate Split : '.$row['associate_split'].$revenue_setting['associate_split'].' = '.$rr.'%';echo '<br>'; 
                                            
                                        ?>
                                        <?php
                                            if ($row['status'] == 'Live') { 
                                                
                                            ?>
                                            <a href='https://marrs.in/franchiselogin/manage/competitionshedule/percentage/<?php echo $row['id']; ?>' target='_BLANK' class='btn btn-warning'>Edit Percentage</a>
      
                                        <?php } ?>
                                        <?php
                                            if ($row['aviansys_split'] == 'yes') { 
                                            ?><a href='https://marrs.in/franchiselogin/manage/competitionshedule/payments/<?php echo $row['id']; ?>' target='_BLANK' class='btn btn-success'>View Payments</a>
      
                                        <?php } ?>  
                                        
                                        
						            </td>
						            
						            <td>
						                <?php 
						                if(empty($revenue_setting)){
						                
    						                echo  'Competition : Rs '.$row['product_price'];echo '<br>';
    						                if(!empty($row['study_material_a']) or !empty($row['study_material_a_price']) ){    echo  $row['study_material_a'].' : Rs '.$row['study_material_a_price'];echo '<br>'; }
                                            if(!empty($row['study_material_b']) or !empty($row['study_material_b_price'])){   echo  $row['study_material_b'].' : Rs '.$row['study_material_b_price'];echo '<br>';}
                                            if(!empty($row['study_material_c']) or !empty($row['study_material_c_price'])){   echo  $row['study_material_c'].' : Rs '.$row['study_material_c_price'];echo '<br>';}
                                            
                                            if(!empty($row['study_material_d']) or !empty($row['study_material_d_price']) ){    echo  $row['study_material_d'].' : Rs '.$row['study_material_d_price'];echo '<br>'; }
                                            if(!empty($row['study_material_e']) or !empty($row['study_material_e_price'])){   echo  $row['study_material_e'].' : Rs '.$row['study_material_e_price'];echo '<br>';}
                                            if(!empty($row['study_material_f']) or !empty($row['study_material_f_price'])){   echo  $row['study_material_f'].' : Rs '.$row['study_material_f_price'];echo '<br>';}
                                            
                                            
                                            
                                            if(!empty($row['orientation_a']) or !empty($row['orientation_a_price'])){     echo  $row['orientation_a'].' : Rs '.$row['orientation_a_price'];echo '<br>';}
                                            if(!empty($row['orientation_b']) or !empty($row['orientation_b_price'])){     echo  $row['orientation_b'].' : Rs '.$row['orientation_b_price'];echo '<br>';}
                                            if(!empty($row['orientation_c']) or !empty($row['orientation_c_price'])){    echo  $row['orientation_c'].' : Rs '.$row['orientation_c_price'];echo '<br>';}
                                            if(!empty($row['orientation_d']) or !empty($row['orientation_d_price'])){     echo  $row['orientation_d'].' : Rs '.$row['orientation_d_price'];echo '<br>';}
                                            if(!empty($row['orientation_e']) or !empty($row['orientation_e_price'])){     echo  $row['orientation_e'].' : Rs '.$row['orientation_e_price'];echo '<br>';}
                                            if(!empty($row['orientation_f']) or !empty($row['orientation_f_price'])){    echo  $row['orientation_f'].' : Rs '.$row['orientation_f_price'];echo '<br>';}
                                            
                                            
                                            
                                            if(!empty($row['mock_test']) or !empty($row['mock_test_price'])){    echo  $row['mock_test'].' : Rs '.$row['mock_test_price'];  }
                                            
                                            
						                }else{
						                    echo  'Competition : Rs '.$revenue_setting['product_price'];echo '<br>';
						                    
    						                if(!empty($revenue_setting['study_material_a_price'])){ echo 'Study Material<br> A : Rs '.$revenue_setting['study_material_a_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['study_material_b_price'])){ echo 'B : Rs '.$revenue_setting['study_material_b_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['study_material_c_price'])){ echo 'C : Rs '.$revenue_setting['study_material_c_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['study_material_d_price'])){ echo 'D : Rs '.$revenue_setting['study_material_d_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['study_material_e_price'])){ echo 'E : Rs '.$revenue_setting['study_material_e_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['study_material_f_price'])){ echo 'F : Rs '.$revenue_setting['study_material_f_price'];echo '<br>'; }
                                            
                                            echo 'Orientation<br>';
                                            if(!empty($revenue_setting['orientation_a_price'])){     echo  'A : Rs '.$revenue_setting['orientation_a_price'];echo '<br>';}
                                            if(!empty($revenue_setting['orientation_b_price'])){     echo  'B : Rs '.$revenue_setting['orientation_b_price'];echo '<br>';}
                                            if(!empty($revenue_setting['orientation_c_price'])){     echo  'C : Rs '.$revenue_setting['orientation_c_price'];echo '<br>';}
                                            
                                            if(!empty($revenue_setting['mock_test_a_price'])){ echo 'Mock Test<br> A : Rs '.$revenue_setting['mock_test_a_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['mock_test_b_price'])){ echo 'B : Rs '.$revenue_setting['mock_test_b_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['mock_test_c_price'])){ echo 'C : Rs '.$revenue_setting['mock_test_c_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['mock_test_d_price'])){ echo 'D : Rs '.$revenue_setting['mock_test_d_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['mock_test_e_price'])){ echo 'E : Rs '.$revenue_setting['mock_test_e_price'];echo '<br>'; }
                                            if(!empty($revenue_setting['mock_test_f_price'])){ echo 'F : Rs '.$revenue_setting['mock_test_f_price'];echo '<br>'; }
                                            
                                            
                                            if(!empty($revenue_setting['mock_test'])){    echo  $revenue_setting['mock_test'].' : Rs '.$revenue_setting['mock_test_price'];  }
						                }    
                                            
                                        if(empty($revenue_setting)){    
						                ?>
						                
						                <button name='edit_price' value='<?php echo $row['id']; ?>' class='btn btn-primary'>Edit Price</button>
    						            </br>
						                <a href='https://marrs.in/franchiselogin/manage/competitionshedule/comp_mat_assign/<?php echo $row['id']; ?>' target="_BLANK"  class='btn btn-warning' >Assign Materials</a>
						                
						                </br>
						                <a href='https://marrs.in/franchiselogin/manage/competitionshedule/comp_mock_assign/<?php echo $row['id']; ?>' target="_BLANK"  class='btn btn-success' >Assign Mock Tests</a>
						                <?php } ?>
						                
						            </td>
						            
						            <!--<td>-->
						                <?php 
						                  //  if(!empty($row['combo_1'])){    echo  $row['combo_1'].' : Rs '.$row['combo_1_price'];echo '<br>'; }
                        //                     if(!empty($row['combo_2'])){   echo  $row['combo_2'].' : Rs '.$row['combo_2_price'];echo '<br>';}
                        //                     if(!empty($row['combo_3'])){   echo  $row['combo_3'].' : Rs '.$row['combo_3_price'];echo '<br>';}
                        //                     if(!empty($row['combo_4'])){     echo  $row['combo_4'].' : Rs '.$row['combo_4_price'];echo '<br>';}
						                    
						                    
						                ?>
						            <!--</td>-->
						            <td>
						                
						                <?php 
						                $center = $this->db->get_where('exam_centers',array('comp_id'=>$row['id']))->result_array();
						                
						                $center1 = $this->db->get_where('closing_competition_details',array('competition_id'=>$row['id']))->result_array();
						                
						                $date='';
						                if(!empty($center[0]['exam_date'] && $center[0]['exam_date']!='0000-00-00')){
						                    $date=$center[0]['exam_date'];
						                }
						                if(!empty($center1[0]['exam_date'] && $center1[0]['exam_date']!='0000-00-00')){
						                    $date=$center1[0]['exam_date'];
						                }
						                if(!empty($row['close_date']) &&  $row['close_date']!='0000-00-00'){
						                    $date=$row['close_date'];
						                }
						                if(!empty($date)){
						                    echo 'Competition Close Date: '.$date.'<br>';
						                }else{
						                    echo 'No Closing Date <br>';
						                }
						                
						                
						                if (!empty($row['crm_fix'])) {
						                    echo 'CRM Fix Amount: '.$row['crm_fix'].'<br>';
						                }
						                elseif(!empty($revenue_setting['crm_fix'])) {
						                    echo 'CRM Fix Amount: '.$revenue_setting['crm_fix'].'<br>';
						
						                }
						                
						                else{
						                    echo 'No CRM Fix Amount <br>';
						                }
    						                    
						                    echo 'CRM %: '.$revenue_setting['crm_per'].'<br>';
						                    echo 'Competition Status'.' => '.$row['status'];
						                    
						                ?>
						                
						                <button name='status' value='<?php echo $row['id']; ?>' <?php if($row['status']=='Closed'){?>class='btn btn-danger' <?}else{?>class='btn btn-success' <?php } ?> >
    						                <?php 
    						                    
    						                    echo 'Change Status';
    						                    
    						                ?>
						                </button>
						                
						                <button name='delete' value='<?php echo $row['id']; ?>' class='btn btn-primary'>
    						                <?php 
    						                    
    						                    echo 'Delete';
    						                    
    						                ?>
						                </button><br>
						                
						                <button name='com_edit' value='<?php echo $row['id']; ?>' class='btn btn-dark'>
    						                <?php 
    						                    
    						                    echo 'Edit Competition';
    						                    
    						                ?>
						                </button><br>
						                
						            </td>
						            <td>
						                <?php
						                 $stat = $this->db->get_where('closing_competition_details',array('competition_id'=>$row['id']))->row();
						                if(empty($stat)){?>
						                <!--<button name='close' class='btn btn-warning' value='<?php echo $row['id']; ?>'>Add closing details for admit card release</button>-->
						                
						                <a href='https://marrs.in/franchiselogin/manage/competitionshedule/close_exam/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-warning' >Close Cart Item Manually</a><br>
						                
						                
						                
						                <?php }else{ 
						                   
						                   
						                    
						                  //  echo '<b>'.'Orientation'.'</b><br>';
						                  //  echo ' A Date :'.$stat->orientation_a_date.'<br>';echo ' A Time :'.$stat->orientation_a_time.'<br>';
						                  //  echo ' B Date :'.$stat->orientation_b_date.'<br>';echo ' B Time :'.$stat->orientation_b_time.'<br>';
						                  //  echo ' C Date :'.$stat->orientation_c_date.'<br>';echo ' C Time :'.$stat->orientation_c_time.'<br>';
						                    
						                  //  echo '<b>'.'Mock Test'.'</b><br>';
						                  //  echo ' Date :'.$stat->mocktest_a_date;echo ' Time :'.$stat->mocktest_a_time;
						                    
						                    
						              //  print_r($stat);
						                ?>
						                 <!--<button name='edit_closing' class='btn btn-success' value='<?php echo $row['id']; ?>'>Edit closing details</button>-->
						                 
						                 <a href='https://marrs.in/franchiselogin/manage/competitionshedule/close_exam/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-warning' >Close Cart Item Manually</a><br>
						                
						                 
						                <?php
						                } ?>
						                
						            </td>
						            
						            <td>
						               
						                <a href='https://marrs.in/franchiselogin/manage/competitionshedule/cin_upload/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-warning' >Upload CIN List To Appear</a><br>
						                   <br>
						                <?php 
						                  //   echo '<b>'.'Exam Details'.'</b><br>';
						                    $center = $this->db->get_where('exam_centers',array('comp_id'=>$row['id']))->result_array();
						                   if(empty($center)){  echo '<-Add closing details for admit card release.';?>
						                      <button name='add_center' class='btn btn-warning' value='<?php echo $row['id']; ?>'>Add Exam Center</button>
						                  <?php }else{ 
						                   ?>
						                   <button name='center' class='btn btn-info' value='<?php echo $row['id']; ?>'>Edit Center details</button><br>
						                    <!--<button name='edit_center' class='btn btn-success' value='<?php echo $row['id']; ?>'>Edit Center details</button>-->
						                   <?php } ?>
						                   <br>
						                   <form method="POST">
						                       
						                        <button value='<?php echo $row['id']; ?>' name="export" class='btn btn-primary' >Unregistered CIN List</button>
						                
						                   </form>
						                   
						                  <!--</br>-->
						                  <br>
						                  <a href='https://marrs.in/franchiselogin/manage/competitionshedule/cin_upload_list/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-success' >Active CIN List</a><br>
						                   
						                  <br>
						                  <?php if(empty($row['pemplate'])){ ?>
						                    <a href='https://marrs.in/franchiselogin/manage/competitionshedule/pemplate/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-primary' >Upload Circular</a><br>
						                  <?php }else{ ?>
						                    <a href='https://marrs.in/franchiselogin/manage/competitionshedule/edit_pemplate/<?php echo $row['id']; ?>' target="_BLANK" class='btn btn-primary' >Edit Circular</a><br>
						                  
						                    <a href='https://marrs.in/franchiselogin/uploads/<?php echo $row['pemplate']; ?>' target="_BLANK" class='btn btn-warning' >View Circular</a><br><br>
						                    <?php if($row['id'] == '521'){ ?>
                                                    <a href='https://marrs.in/franchiselogin/manage/competitionshedule/reminderEmail/<?php echo $row['id'];?>'  class='btn btn-warning'>Reminder Email</a><br>
                                                <?php } ?>
						                  <?php } ?>
						                  
						                  
						                   
						            </td>
						                    
						          </tr>
						          <?php 
						          $i=$i+1;
						          } ?>
						          </table>
						      
						
							</fieldset>
						  </form>
					
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
<?php include('footer.php'); ?>

<script src="<?php echo VIEW_SCRIPT;?>jquery-1.9.1.min.js"></script>
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js" ></script>-->


<script type="text/javascript">
    

       $("#state_id").change(function(){
        var state_id=this.value;
		//alert(state_id);
		var BASE_URL = "<?php echo base_url();?>";
        $.ajax({
            url:BASE_URL+"manage/ajax/getStateFranchise/",
            data:{state_id:state_id},
            type: 'post',
            success:function(result){
                 $("#franchise_id").html(result);
        }});
    }); 
	$("#product_name").change(function(){
        var product_id=this.value;
		//alert(state_id);
		var BASE_URL = "<?php echo base_url();?>";
        $.ajax({
            url:BASE_URL+"manage/ajax/productwiselevel/",
            data:{product_id:product_id},
            type: 'post',
            success:function(result){
                 $("#competition_level_id").html(result);
        }});
    }); 
		$("#franchise_id").change(function(){
        var franchise_id=this.value;
		//alert(state_id);
		var BASE_URL = "<?php echo base_url();?>";
        $.ajax({
            url:BASE_URL+"manage/ajax/AreaCode/",
            data:{franchise_id:franchise_id},
            type: 'post',
            success:function(result){
                 $("#area_id").html(result);
        }});
    }); 
    
    $("#product_name").change(function(){
        var product_id=this.value;
		//alert(state_id);
		var BASE_URL = "<?php echo base_url();?>";
        $.ajax({
            url:BASE_URL+"manage/ajax/class_category/",
            data:{product_id:product_id},
            type: 'post',
            success:function(result){
                 $("#category_id_").html(result);
        }});
    }); 
    
 </script>
 
 <script>
 
    
 
    $("#country").change(function(){
        var country_id =this.value;
         //alert(franchise_id);
         var BASE_URL="https://marrs.in/franchiselogin/";
        $.ajax({
        url:"https://marrs.in/franchiselogin/manage/ajax/getstateAjax_",
        data:{country_id:country_id},
        type: 'post',
        success:function(result)
        {
        	//alert(result);
        	 $("#state").html(result);
        	 
        
        }});
    });
 
    $("#product").change(function(){
        var product_id =this.value;
         //alert(franchise_id);
         var BASE_URL="https://marrs.in/franchiselogin/";
        $.ajax({
        url:"https://marrs.in/franchiselogin/manage/ajax/productwiselevelwithName",
        data:{product_id:product_id},
        type: 'post',
        success:function(result)
        {
        	//alert(result);
        	 $("#level").html(result);
        	 
        
        }});
    });
    
    
</script>
 <style>
.vl {
  border-left: 2px solid gray;
  height: 80px;
}
</style>
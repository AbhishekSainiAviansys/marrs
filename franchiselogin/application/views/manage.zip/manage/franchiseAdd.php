<?php include('header.php'); ?>

<style>
input.chk {
    margin-left: 20px;
    margin-top:10px;
}  
.form-horizontal .controls {
   
    margin-left: 150px;
  
}
input[type="text"] {
    width: 96%;
}
.section-divider {
    border-top: 2px solid #ddd;
    text-align: center;
    margin-top: 20px;
    margin-bottom: 30px;
    margin-left: 20px;
    margin-right: 20px;
}
span.info {
    display: inline-block;
    position: relative;
    padding: 1px 30px 2px 30px;
    top: -11px;
    font-size: 18px;
    color: #4B4B4B;
    background-color: #fff;
}
    
</style>
    <div>
        <ul class="breadcrumb">
            <li><a href="<?php echo SITE_URL?>student/">Franchise</a> <span class="divider">/</span></li>
            <li><a href="<?php echo SITE_URL?>student/<?php echo ($studentID>0)?'edit':'add';?>/"><?php echo ($studentID>0)?'Edit':'Add';?></a></li>
        </ul>
    </div>
<?php echo $this->notifications->display_html();?>


<div class="row-fluid sortable">
	<div class="box span12">
    
		<div class="box-header well" data-original-title>
			 <h2><i class="icon-edit"></i> Franchise <?php echo ($studentID>0)?'Edit':'Add';?></h2>
					<div class="box-icon">
						<a href="#" class="btn btn-setting btn-round"><i class="icon-cog"></i></a>
						<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
						<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
					</div>
		</div>
	    <div class="box-content">
			<form class="form-horizontal" method="POST" enctype= "multipart/form-data">
				  <fieldset>
                    
                      <!-----------------School Name------------------->       
                             
                             
                             
                             
                             
                             
                    <div class="section-divider"> <span class="info">Contact Details </span></div>
							 <!-----------------Country-------------------> 
							 <div class="col-lg-12" style="display:flex;padding-bottom:30px">
							      <div class="span4">
								<label class="control-label" for="focusedInput">Country
                                <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                </label>
								<div class="controls">
								    
								    <select name="country_id" id="country_id">
									    <?php 
								        $this->db->select('*');
								        $this->db->from('countries');
								        $resc = $this->db->get();
								       $coun = $resc->result_array();
								        foreach($coun as $val){ ?>
								        <option value="<?php echo $val['country_id'];?>" <?php if($val['country_id']==$result['country_id']) { echo 'selected="selected"';} ?>><?php echo $val['country_name'];?></option>
								       
								        <?php }?>
								    </select>
								   
									     
								 	<span class="help-inline"><?php  $this->validation->show_error('country_id',"Please enter the country.") ?></span>
								</div>
						   </div>
							   <div class="span4">
								<label class="control-label" for="focusedInput">State/Province
                                <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                </label>
								<div class="controls">
								    
								    <select name="state_id" id="state_id">
								      <?php 
								        $this->db->select('*');
								        $this->db->from('states');
								        $resc = $this->db->get();
								       $coun = $resc->result_array();
								        foreach($coun as $val){ ?>
								        <option value="<?php echo $val['state_subdivision_id'];?>" <?php if($val['state_subdivision_id']==$result['state_id']) { echo 'selected="selected"';} ?>><?php echo $val['state_subdivision_name'];?></option>
								       
								        <?php }?>
								    </select>
								   
									     
								 	<span class="help-inline"><?php  $this->validation->show_error('state_id',"Please enter the country.") ?></span>
								</div>
						   </div>
                          
                    <!-----------------State/Province------------------->       
						   <div class="span4">
								<label class="control-label" for="focusedInput">Area
                                <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                </label>
								<div class="controls"  id="area">
								    <?php 
								        $this->db->select('areas.id,areas.area_code');
								        $this->db->from('area_to_franchise');
								        $this->db->join('areas','area_to_franchise.area_id=areas.id','left');
								        $this->db->where('area_to_franchise.franchise_id',$result['franchise_id']);
								        $resc = $this->db->get();
								       $coun = $resc->result_array();
								       //print_r($coun);die;
								         foreach($coun as $val){ ?>
								   
								  <input type="checkbox" name="area" value="<?php echo $val['area_code'];?>" checked><?php echo $val['area_code'];?>
								    
								  <?php } ?> 
								
								</div>
						   </div> 
                    <!-----------------Shool City ------------------->       
                            
                            
							 </div>
							  <!-----------------Shool City ------------------->       
                              <div class="col-lg-12" style="display:flex">
                                  
                                 
                            </div>
                          
                            <div class="col-lg-12" style="display:flex">
                                <div class="span4">
								 <label class="control-label" for="focusedInput">Address Line1
                                 <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                 </label>
								 <div class="controls">
								      <input class="" id="school_address" name="address" type="text" value="<?php if( isset( $result['company_address'] ) )echo $result['company_address']; ?>" required>
                                      <span class="help-inline"><?php  $this->validation->show_error('company_address',"Please enter the  address1.") ?></span>						
								 </div>
							</div>
							
							<div class="span4">
								 <label class="control-label" for="focusedInput">Address Line2</label>
								 <div class="controls">
								      <input class="" id="school_address1" name="address1" type="text" value="<?php if( isset( $result['company_address1'] ) )echo $result['company_address1']; ?>" >
                                      <span class="help-inline"><?php  $this->validation->show_error('company_address1',"Please enter the  address2.") ?></span>						
								 </div>
							</div>
							<!--<div class="span4">
							<div class="controls">
							<a class="btn bnt-primary" style="background: #c6003f;
    color: #fff;" href="<?php echo base_url();?>manage/franchise/Addfrachise/">clear</a>
							</div>	 
							</div>-->
					
						</div>
						<div class="col-lg-12" style="display:flex">
						   <div class="span4">
						<label class="control-label" for="focusedInput">Franchise Type
                        <span style="color:#F00; font-size:15px;"><b>*</b></span>
                        </label>
							   <div class="controls">
								    <select class="span12" name="franchise_type" id="franchise_type" required>
                                            <option value="">Select</option>
                                            <option value="1"<?php if( isset( $result['franchise_type'] ) ) if($result['franchise_type']=='1') {  ?> selected="selected" <?php } ?> >Super Franchise</option>
                                             <option value="2"<?php if( isset( $result['franchise_type'] ) ) if($result['franchise_type']=='2') {  ?> selected="selected" <?php } ?> >National Franchise</option>
                                              <option value="3" <?php if( isset( $result['franchise_type'] ) ) if($result['franchise_type']=='3') {  ?> selected="selected" <?php } ?> selected>State Franchise</option>
                                               <option value="4" <?php if( isset( $result['franchise_type'] ) ) if($result['franchise_type']=='4') {  ?> selected="selected" <?php } ?>>District Franchise</option>
                                      </select>
								     <span class="help-inline"><?php  $this->validation->show_error('franchise_type',"Please select") ?></span>
                              </div>
				        	</div>
				        	<div class="span4">
								 <label class="control-label" for="focusedInput">Franchise Ref</label>
								 <div class="controls">
								      <input class="" id="school_address1" name="franchise_ref" type="text" value="<?php if(isset($result['franchise_ref'])){ echo $result['franchise_ref']; }?>" >
                                      <span class="help-inline"><?php  $this->validation->show_error('franchise_ref',"Please enter the school address2.") ?></span>						
								 </div>
							</div>
					
						</div>
						
						<div class="section-divider"> <span class="info">Personal Information</span></div>
							 <div class="col-lg-12" style="display:flex">
						   <div class="span4">
								  <label class="control-label" for="focusedInput">First Name
                                  <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                  </label>
								  <div class="controls">
								     <input type="text" class="span12" id="frenchise_first_name" name="frenchise_first_name" value="<?php if(isset($result['franchise_first_name'])){ echo $result['franchise_first_name']; }?>" required>
								         
								       
                                     <span class="school-error" style="color:red;"><?php  echo $this->session->flashdata('message'); ?></span>							 					
								   </div>
								   
							 </div>
						 
						 <div class="span4">
								  <label class="control-label" for="focusedInput">Last Name
                                  <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                  </label>
								  <div class="controls">
								     <input type="text" class="span12" id="frenchise_last_name" name="frenchise_last_name" value="<?php if(isset($result['franchise_last_name'])){ echo $result['franchise_last_name']; }?>" required>
								         
								       
                                     <span class="school-error" style="color:red;"><?php  echo $this->session->flashdata('message'); ?></span>							 					
								   </div>
								   
							 </div>
                      <!-----------------Affiliation Number------------------->       
							<div class="span4">
								 <label class="control-label" for="focusedInput">Mobile Number</label>
								 <div class="controls">
								      <input class="span12" id="mobile_number" name="mobile_number" type="text" value="<?php if( isset( $result['mobile_number'] ) )echo $result['mobile_number']; ?>" >
                                      <span class="help-inline"><?php  $this->validation->show_error('mobile_number',"Please enter the school affiliation number.") ?></span>							 				
								</div>
							</div>
							
						
							</div>
						
							
							 
							
                     
                  
                         
                   
                   
                    <!-----------------school Concern ------------------->  
                     <div class="col-lg-12" style="display:flex">
                         	<div class="span12">
								  <label class="control-label" for="focusedInput">Company Email
                                  <span style="color:#F00; font-size:15px;"><b>*</b></span>
                                  </label>
								  <div class="controls">
								       <input class="span12" id="company_email_id" name="company_email_id" type="email" value="<?php if( isset( $result['company_email_id'] ) ) { echo $result['company_email_id'];} ?>" required>
                                       <span class="help-inline"><?php  $this->validation->show_error('company_email_id',"Please enter the School Principal Name.") ?></span>							 					
								  </div>
						  </div>
                   <div class="span12">
                         <label class="control-label" for="focusedInput"> Company Name
                         
                         </label>
                                 <div class="controls">
                                      <input type="text" class="span12" name="company_name" id="company_name" value="<?php if(isset($result['company_name'])){ echo $result['company_name']; }?>">
                                          
                                      <span class="help-inline"><?php  $this->validation->show_error('company_name',"Please enter the school concern status.") ?></span>							
                                </div>
                   </div>
                    <!-----------------School Latitude ------------------->       
                  <div class="span12">
                        <label class="control-label" for="focusedInput">Franchise Status</label>
                               <div class="controls">
                                     <select class="span12" id="franchise_status" name="franchise_status">
                                         <option value="Active" <?php if( isset( $result['franchise_status'] ) ) if($result['franchise_status']=='Active') {  ?> selected="selected" <?php } ?>>Active</option>
                                          <option value="Deactive" <?php if( isset( $result['franchise_status'] ) ) if($result['franchise_status']=='Deactive') {  ?> selected="selected" <?php } ?>>Deactive</option>
                                         </select>
                                    <span class="help-inline"><?php  $this->validation->show_error('school_latitude',"Please enter the school latitude.") ?></span>							 
                              </div>
                   </div>
                        
                   
                   <!--<div class="span12">
                         <label class="control-label" for="focusedInput">School Longitude</label>
                                <div class="controls">
                                     <input class="" id="school_longitude" name="school_longitude" type="text" value="<?php if( isset( $result['school_longitude'] ) )echo $result['school_longitude']; ?>" >
                                     <span class="help-inline"><?php  $this->validation->show_error('school_longitude',"Please enter the school longitude.") ?></span>							
                                </div>
                   </div>-->
                   
                    <!-----------------Competition center ------------------->       
				  
					</div>
					
					
					
				
					
					<div class="section-divider"> <span class="info">MaRRS Learning Programs</span></div>
						 <div class="col-lg-12" style="display:block">
						     <input  type="hidden" value='<?php echo $result['franchise_id'];?>' id="fid">
								  <label class="control-label" for="focusedInput"> 
                                  <span style="color:#F00; font-size:15px;"><b></b></span>
                                  </label>
								  <div class="controls" style="columns: auto 1;">
								     <?php  
								    $fid =$result['franchise_id'];
								   
								   $this->db->select('*');
								   $this->db->from('products');
								   $this->db->join('product_allotted_fr','product_allotted_fr.product_id=products.product_id');
								   $this->db->where('product_allotted_fr.franchise_id',$result['franchise_id']);
								   $this->db->where('product_allotted_fr.status','Active');
								   $res = $this->db->get();
								   //echo $this->db->last_query();die;
								   $result = $res->result_array();
								   //print_r($result);exit;
								   foreach($result as $val){    
								   
								   ?>
								    <level>
								   <input type="checkbox" name="product_id[]" id="product_id" value="<?php echo $val['product_id'];?>" >&nbsp;<?php  echo $val['product_name'];
								   ?>
								  </level><br> 
								  
								  
								  <span><select name="product_price[]" class="chk" placeholder="Price" style="margin-top: -40px;margin-left: 370px;">  
								   
								   <?php 
								    $this->db->select('price_codegenration.id,price_codegenration.price_code');
                                    $this->db->from('price_codegenration');
                                    $this->db->join('franchise_to_pricecode','franchise_to_pricecode.pricecode_id=price_codegenration.id');
                                    //$this->db->where('status','Active');
                                    $this->db->where('franchise_to_pricecode.franchise_id',$fid);
                                    $this->db->where('franchise_to_pricecode.product_id',$val['product_id']);
								    $res = $this->db->get();
								    $results = $res->result_array();
								   foreach($results as $value){ ?>
								       
								       <option value="<?php echo $value['id'];?>"><?php echo $value['price_code'];?></option>
								       <?php  } ?>
								   </select> </span><br>
								   
								   <?php }   ?>
								   
								   </div>
							 </div>
						
					
                    <!-----------------Submit /Cancel button ------------------->       
                    
				   <div class="form-actions">
								<input type="submit" class="btn btn-primary" id="submit" value="submit" name="submit" >
								<button class="btn">Cancel</button>
				  </div>
               </fieldset>
	         </form>
	     </div><!-- END OF  class- box-content -->  
	 </div><!--END of class- box span12 DIV--> 
  </div><!--END OF class- row-fluid sortable" DIV-->
<script>

$("#country_id").change(function(){
		   
		//alert(this.value);
        var country_id=this.value;
        $.ajax({
            url: "<?php echo base_url();?>"+"manage/ajax/getstateAjax/",
            data:{country_id:country_id},
            type: 'post',
            success:function(result){
				// alert(result);
                 $("#state_id").html(result);
        }});
    }); 
	
	$("#state_id").change(function(){
		   
		//alert(this.value);
        var state_id=this.value;
        $.ajax({
            url: "<?php echo base_url();?>"+"manage/ajax/getAreaAjax/",
            data:{state_id:state_id},
            type: 'post',
            success:function(result){
				// alert(result);
                 $("#area").html(result);
        }});
    }); 
	
	$("#district").change(function(){
		   
		//alert(this.value);
        var district=this.value;
        $.ajax({
            url: "<?php echo base_url();?>"+"manage/ajax/getAreaAjax/",
            data:{district:district},
            type: 'post',
            success:function(result){
				// alert(result);
                 $("#district").html(result);
        }});
    });
</script>
 
<script>
    $(document).ready(function(){
        $('input[type="checkbox"]').click(function(){
            if($(this).prop("checked") == true){
                var id = $(this).val();
               var dataid = $('#fid').val();
               //alert(dataid);
                	$.ajax({
                           	url:BASE_URL+"manage/franchise/productActiveDeactive/",
                            type:'post',
                            data:{ 'id' : id, 'fid' : dataid },
                            success:function(data){
                            			
                             }
                        	}); 
                
            }
            else if($(this).prop("checked") == false){
               var id = $(this).val();
               var dataid = $('#fid').val();
               //alert(dataid);
                	$.ajax({
                           	url:BASE_URL+"manage/franchise/productActiveDeactive/",
                            type:'post',
                            data:{ 'id' : id, 'fid' : dataid },
                            success:function(data){
                            			
                             }
                        	}); 
            }
        });
    });
</script>

<?php include('footer.php'); ?>

<head>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<style>
    .footer{
        display: flex;
        justify-content: space-around;
        color: #ffffff;
        background-color: #4775d1;
        height: 40px;
        flex-wrap: wrap;
        align-content: center;
        align-items: flex-end;
    }
    .footer a{
        color:#ffffff;
        padding-top:10px;
    }
</style>

</head>	


		<script>
			var VIEW_STYLE='<?php echo VIEW_STYLE;?>';
			var COMMON_VIEW_SCRIPT='<?php echo COMMON_VIEW_SCRIPT;?>';
			var BASE_URL='<?php echo BASE_URL;?>';
			
			var COMMON_VIEW_STYLE='<?php echo COMMON_VIEW_STYLE;?>';
			var COMMON_COMMON_VIEW_SCRIPT='<?php echo COMMON_COMMON_VIEW_SCRIPT;?>';
			var COMMON_BASE_URL='<?php echo COMMON_BASE_URL;?>';
			
		</script>



    <footer class="footer">
    
        <h5 style='color:#ffffff;'>© <a href="#" class="text-white">MaRRS Rediscover Pvt. Ltd. <?php echo date("Y",strtotime("-1 year")).' - '.date('Y');?></a></h5>
        <h5 style='color:#ffffff;'>Powered By: <a href="https://www.aviansys-tech.com/" class="text-white">Aviansys Technologies Pvt. Ltd.</a></h5>
        
    </footer>


	<script src="<?php echo COMMON_VIEW_SCRIPT;?>jquery-ui-1.8.21.custom.min.js"></script>
	<!-- transition / effect library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-transition.js"></script>
	<!-- alert enhancer library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-alert.js"></script>
	<!-- modal / dialog library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-modal.js"></script>
	<!-- custom dropdown library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-dropdown.js"></script>
	<!-- scrolspy library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-scrollspy.js"></script>
	<!-- library for creating tabs -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-tab.js"></script>
	<!-- library for advanced tooltip -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-tooltip.js"></script>
	<!-- popover effect library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-popover.js"></script>
	<!-- button enhancer library -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-button.js"></script>
	<!-- accordion library (optional, not used in demo) -->
	<script src="<?php echo COMMON_VIEW_SCRIPT;?>bootstrap-collapse.js"></script>
	<!-- carousel slideshow library (optional, not used in demo) -->


	
	
	
</body>
</html>

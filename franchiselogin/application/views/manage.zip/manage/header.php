<!DOCTYPE html>
<html lang="en">
<head>

  <!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-133722627-1"></script>

<script>
  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());

  gtag('config', 'UA-133722627-1');
</script>
<style>
		/* MAIN DROPDOWN */
.modern-menu {
    border-radius: 12px;
    padding: 8px 0;
    min-width: 260px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.12);
    border: none;
    background: #fff;
}

/* MAIN ITEMS */
.modern-menu > li > a {
    padding: 12px 18px;
    font-size: 14px;
    color: #333;
    display: block;
    transition: all 0.25s ease;
}

/* HOVER EFFECT */
.modern-menu > li > a:hover {
    background: #f1f5f9;
    color: #007bff;
}

/* SUBMENU CONTAINER */
.dropdown-submenu {
    position: relative;
}

/* SUBMENU DESIGN (🔥 FIXED LOOK) */
.dropdown-submenu > .dropdown-menu {
    top: 0;
    left: 98%;
    margin-left: 8px;
    border-radius: 12px;
    padding: 10px 0;
    min-width: 240px;
    background: #ffffff;
    box-shadow: 0 12px 35px rgba(0,0,0,0.15);
    display: none;
    border: none;
}

/* SHOW SUBMENU */
.dropdown-submenu.open > .dropdown-menu {
    display: block;
}

/* SUBMENU ITEMS */
.dropdown-submenu .dropdown-menu li a {
    padding: 10px 16px;
    font-size: 13px;
    color: #444;
    transition: all 0.25s ease;
}

/* SUBMENU HOVER */
.dropdown-submenu .dropdown-menu li a:hover {
    background: #eef4ff;
    color: #0056d2;
    padding-left: 20px;
}

/* ARROW STYLE */
.arrow {
    margin-left:10px;
    transition: transform 0.2s ease;
}

/* ROTATE ARROW WHEN OPEN */
.dropdown-submenu.open > a .arrow {
    transform: rotate(90deg);
}

/* ADD LEFT BORDER INDICATOR */
.dropdown-submenu .dropdown-menu {
    border-left: 3px solid #007bff;
}
.navbar .navbar-inner{
    background-color: #f26522 !important;
}
.nav > li > a:hover {
    text-decoration: none;
    background-color: #bf2323 !important;
    color: #FFF;
}</style>
	<meta charset="utf-8">
	<title>SITE NAME</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">


	<!-- The styles -->
	<link id="bs-css" href="<?php echo COMMON_VIEW_STYLE;?>bootstrap-cerulean.css" rel="stylesheet">
	<style type="text/css">
	  body {
		padding-bottom: 40px;
	  }
	  .sidebar-nav {
		padding: 9px 0;
	  }
	    .brand img {
    float: left;
    height: 24px !important
   
    margin-right: 5px;
    width: 100% !important;
}

.dropdown-menu li {
    list-style: none;   /* remove default dots */
    padding-left: 0;
}


@media only screen and (max-device-width: 480px) {
   

.col-lg-12 {
    display: grid !important;
}
.col-lg-12 input[type="text"] {
    width: 65% !important;
        margin-top: 10px;
}
}
	</style>
	<link href="<?php echo COMMON_VIEW_STYLE;?>bootstrap-responsive.css" rel="stylesheet">
	<link href="<?php echo COMMON_VIEW_STYLE;?>charisma-app.css" rel="stylesheet">
	<link href="<?php echo COMMON_VIEW_STYLE;?>jquery-ui-1.8.21.custom.css" rel="stylesheet">
	<link href='<?php echo COMMON_VIEW_STYLE;?>fullcalendar.css' rel='stylesheet'>
	<link href='<?php echo COMMON_VIEW_STYLE;?>fullcalendar.print.css' rel='stylesheet'  media='print'>
	<link href='<?php echo COMMON_VIEW_STYLE;?>chosen.css' rel='stylesheet'>
	<link href='<?php echo COMMON_VIEW_STYLE;?>uniform.default.css' rel='stylesheet'>
	

	<!-- The fav icon -->
	<link rel="shortcut icon" href="<?php echo VIEW_IMAGE;?>favicon.ico">
		
      



    <script type="text/javascript" src='<?php echo COMMON_VIEW_SCRIPT;?>jquery-1.7.2.min.js'></script>    
</head>

<body>
	<?php if(!isset($no_visible_elements) || !$no_visible_elements)	{ ?>
	<!-- topbar starts -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href=""> <img alt="Logo" src="<?php echo base_url();?>public/logo/marrs-logo.png" />  <span><?php echo $this->session->userdata('instituteName');?></span></a>
				
				<!-- theme selector starts -->
				<!--<div class="btn-group pull-right theme-container" >
					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
						<i class="icon-tint"></i><span class="hidden-phone"> Change Theme / Skin</span>
						<span class="caret"></span>
					</a>
					<ul class="dropdown-menu" id="themes">
						<li><a data-value="classic" href="#"><i class="icon-blank"></i> Classic</a></li>
						<li><a data-value="cerulean" href="#"><i class="icon-blank"></i> Cerulean</a></li>
						<li><a data-value="cyborg" href="#"><i class="icon-blank"></i> Cyborg</a></li>
						<li><a data-value="redy" href="#"><i class="icon-blank"></i> Redy</a></li>
						<li><a data-value="journal" href="#"><i class="icon-blank"></i> Journal</a></li>
						<li><a data-value="simplex" href="#"><i class="icon-blank"></i> Simplex</a></li>
						<li><a data-value="slate" href="#"><i class="icon-blank"></i> Slate</a></li>
						<li><a data-value="spacelab" href="#"><i class="icon-blank"></i> Spacelab</a></li>
						<li><a data-value="united" href="#"><i class="icon-blank"></i> United</a></li>
					</ul>
				</div>-->
				<!-- theme selector ends -->
				
				<!-- user dropdown starts -->
				<div class="btn-group pull-right" >
					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
						<i class="icon-user"></i><span class="hidden-phone"> admin</span>
						<span class="caret"></span>
					</a>
					<ul class="dropdown-menu">
					<!--	<li><a href="#">Profile</a></li>
						<li class="divider"></li>-->
						<li><a href="<?php echo SITE_URL?>login/logout/">Logout</a></li>
					</ul>
				</div>
				<!-- user dropdown ends -->
				
				
			</div>
		</div>
	</div>
	<!-- topbar ends -->
	<div class="container-fluid">
		<div class="row-fluid">
		  <?php if(!isset($no_visible_elements) || !$no_visible_elements) { ?>
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="https://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<div id="content" class="span10">
			<!-- content starts -->
			<?php } ?>

			<ul class="nav nav-pills">
              <li <?php if(in_array(CONTROLLER,array('index'))){?> class="active"<?php }?>><a href="<?php echo SITE_URL?>index/">Home</a></li>
           
            
              <li class="dropdown modern-dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="icon-user"></i> Student Registration <b class="caret"></b>
                </a>
            
                <ul class="dropdown-menu modern-menu">
            
                    <!-- Category 1 -->
                    <li class="dropdown-submenu">
                        <a href="#">
                            Registered Students (2023 and above)
                            <span class="arrow">▶</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo SITE_URL?>school/competition_extraction">Competition Extract</a></li>
                            <li><a href="<?php echo SITE_URL?>school/mock_extraction">Mock Extract</a></li>
                            <li><a href="<?php echo SITE_URL?>school/material_extraction">Material Extract</a></li>
                            <li><a href="<?php echo SITE_URL?>school/orientation_extraction">Orientation Extract</a></li>
                        </ul>
                    </li>
            
                    <li class="divider"></li>
            
                    <!-- Category 2 -->
                    <li class="dropdown-submenu">
                        <a href="#">
                            Registered Students (till 2023)
                            <span class="arrow">▶</span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo SITE_URL?>franchise/Cin_extract">Competition Extraction List</a></li>
                            <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_orientation">Orientation Extraction List</a></li>
                            <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_mock">Mock Test Extraction List</a></li>
                            <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_material">Study Material Extraction List</a></li>
                        </ul>
                    </li>
            
                </ul>
            </li>


			  <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/AddPriceCode',base_url().'manage/franchise/acces_code_apporved',base_url().'manage/franchise/accesscode_apporvedList'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#">Price  Codes<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo SITE_URL?>franchise/AddPriceCode">Add PriceCode </a></li> 
                  <li class="divider"></li>
                   <!--<li><a href="<?php echo SITE_URL?>franchise/assignToFranchise">Assign Franchise </a></li> -->
                  <li class="divider"></li>
                  <li><a href="<?php echo SITE_URL?>franchise/acces_code_apporved">Price Code Approval</a></li> 
                  <li class="divider"></li>
                   <li><a href="<?php echo SITE_URL?>franchise/accesscode_apporvedList">Price Codes Approved List</a></li>
                  
			    </ul>
				  </li>
			   
			   
			   
			   
			   <li class="dropdown  <?php if(in_array(current_url(),array(base_url().'manage/franchise/productList',base_url().'manage/franchise/addproduct'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#">Product List <b class="caret"></b></a>
                <ul class="dropdown-menu">
                  
                  <li><a href="<?php echo SITE_URL?>franchise/productList">Product List</a></li>
                   <li class="divider"></li>
                   <li><a href="<?php echo SITE_URL?>franchise/addproduct">Add Product</a></li>
			    </ul>
				  </li>
			  
			   <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/Addarea',base_url().'manage/franchise/listAreacode',base_url().'manage/franchise/franchiseView'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#"> Franchise <b class="caret"></b></a>
                <ul class="dropdown-menu">
                   <li><a href="<?php echo SITE_URL?>franchise/Addarea">Add Area Code</a></li>
                   <li class="divider"></li>
				    <li><a href="<?php echo SITE_URL?>franchise/listAreacode">List Area Code</a></li>
                   <li class="divider"></li>  
				  <li><a href="<?php echo SITE_URL?>franchise/franchiseView">View List</a></li>  
                   <li class="divider"></li>
                   <li><a href="<?php echo SITE_URL?>franchise/Addfrachise">Add Franchise</a></li>
                    <li class="divider"></li>
                    <!--<li><a href="<?php echo SITE_URL?>franchise/view_franchise_logindetails">Login Info</a></li>-->
                    <li class="divider"></li>
                      <li><a href="<?php echo SITE_URL?>franchise/assignToFranchise">Assign Product To Franchise </a></li> 
                    <!--<li><a href="<?php echo SITE_URL?>franchise/assign_area">Assign Franchise Area</a></li>-->
                    <!--<li><a href="<?php echo SITE_URL?>franchise/zoomzoom_franchise">Zoomzoom Franchise Activate</a></li>   -->
			    </ul>
				  </li>
				  
				  
				  <!--  <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/competitionshedule/index',base_url().'manage/competitionshedule/assignschools',base_url().'manage/competitionshedule/add'))){?> active<?php }?>">-->
      <!--          <a class="dropdown-toggle " data-toggle="dropdown" href="#">Competitionshedule <b class="caret"></b></a>-->
      <!--          <ul class="dropdown-menu">-->
                  
      <!--            <li><a href="<?php echo SITE_URL?>competitionshedule/schedule_school_check">Competitionshedule Assigned Schools</a></li>-->
                  
      <!--             <li class="divider"></li>  -->
                  <!--   <li><a href="<?php echo SITE_URL?>competitionshedule/assignschools">competitionshedule School Assign</a></li>-->
                  <!--   <li class="divider"></li>-->
                 
                  
                  
			   <!-- </ul>-->
				  <!--</li>-->
				  
				   <li class="dropdown  <?php if(in_array(current_url(),array(base_url().'manage/franchise/schooListView',base_url().'manage/franchise/generate_accesscode',base_url().'manage/franchise/Addschool'
				   ,base_url().'manage/franchise/bulk_schooladd',base_url().'manage/franchise/bulk_school_template'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#">School <b class="caret"></b></a>
                <ul class="dropdown-menu">
                  
                  <li><a href="<?php echo SITE_URL?>franchise/schooListView">School List</a></li>
                  
                   <!--<li class="divider"></li>-->
                   <!--  <li><a href="<?php echo SITE_URL?>franchise/generate_accesscode">School Acceess Code Approval</a></li>-->
                     <li class="divider"></li>
                     <li><a href="<?php echo SITE_URL?>franchise/Add_school">School Add </a></li>
                     <li class="divider"></li>
                     <li><a href="<?php echo SITE_URL?>franchise/bulk_school_template">Bulk School Template</a></li>
                      <li class="divider"></li>
                       <li><a href="<?php echo SITE_URL?>franchise/bulk_schooladd">Bulk School Upload</a></li>
                        <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>competitionshedule/cmsch"> Assign Product To School - SchoolLevel</a></li>
                             <li class="divider"></li>
                             <li><a href="<?php echo SITE_URL?>competitionshedule/add">Add Competition Shedule </a></li> 
                             <li class="divider"></li>
                  <li><a href='<?php echo SITE_URL?>competitionshedule/schedule_list'>Schedule List</a></li>
                   <li class="divider"></li>                      
                            <li><a href="<?php echo SITE_URL?>competitionshedule/search_school">Extract School QR Code- SchoolLevel</a></li>  
                            <li class="divider"></li>
                             <li><a href="<?php echo SITE_URL?>franchise/assign_product">Promotional Schools Assign Products</a></li>
                            <li class="divider"></li>
                                <li><a href="<?php echo SITE_URL?>franchise/school_list">Promotional School List</a></li>
                            <li class="divider"></li>
                                <li><a href="<?php echo SITE_URL?>franchise/student_list">Promotional Students List</a></li>
                        
                  <!--<li><a href="<?php echo SITE_URL?>franchise/Addschool">School Add with product</a></li>-->
                  <!--<li class="divider"></li>-->
                 
                  <li class="divider"></li>
                  <!--<li><a href="<?php echo SITE_URL?>franchise/assign_pricecode_school">School assign pricecode</a></li>-->
                  <!--<li class="divider"></li>-->
                  
                  
			    </ul>
				  </li>
				  
			    
			    
			    <!--  ============== upload level result product =============== -->
			    
			    <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/student_result_upload',base_url().'manage/franchise/zoomzoom_result_upload',base_url().'manage/franchise/zoomzoomresult_export'))){?> active<?php }?>">
                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Result <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url();?>public/template/MARRS_RESULT_UPLOAD_TEMPLATE.csv"> Result Template </a></li>
                        <!--<li><a href="<?php echo SITE_URL?>public/template/MARRS_RESULT_UPLOAD_TEMPLATE.csv"> Result Template </a></li>-->
                        
                        <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>franchise/student_result_upload1"> Result Upload </a></li>
                        
                        <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>franchise/student_result_edit">Result Edit</a></li>
                          
                        <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>result/result_upload_against_schedule"> Result Upload Against Schedule</a></li>
                      
                        
                      
                         <li class="divider"></li>
                         <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_result_upload">ZoomZoom Result Upload</a></li>
                         <li class="divider"></li>
                         <li><a href="<?php echo SITE_URL?>franchise/zoomzoomresult_export">Export Result Zoomzoom</a></li>
                          <li class="divider"></li>
                         <li><a href="<?php echo SITE_URL?>franchise/resultexport">Export Result</a></li>
    			    </ul>
				</li>
			   
			   <!--  ============== Activate new session and level =============== -->
			 <!--   <li class="dropdown <?php if(in_array(CONTROLLER,array('franchise'))){?> active<?php }?>">-->
    <!--                <a class="dropdown-toggle " data-toggle="dropdown" href="#">Students List<b class="caret"></b></a>-->
    <!--                <ul class="dropdown-menu">-->
                      
    <!--                  <li><a href="<?php echo SITE_URL?>franchise/student_list"> Student Extract </a></li>-->
                      
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/franchise_schoollist">Multiple Franchise School List</a></li>-->
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_extract">ZoomZoom Competition Extract</a></li>-->
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_extract_material">ZoomZoom Material Extract</a></li>-->
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_extract_orientation">ZoomZoom Orientation Extract</a></li>-->
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_mocktest_orientation">ZoomZoom Mock Test Extract</a></li>-->
    <!--                          <li class="divider"></li>-->
    <!--                          <li><a href="<?php echo SITE_URL?>franchise/primary_color_extraction">Primary Color Extract</a></li>-->
                              
    <!--			    </ul>-->
				<!--</li>-->
			   
			   
			   <!--  ============== Activate new session and level =============== -->
			    <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/period',base_url().'manage/franchise/level'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#">Activate <b class="caret"></b></a>
                <ul class="dropdown-menu">
                  
                    <li><a href="<?php echo SITE_URL?>franchise/period"> Period </a></li>
                  
                        <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>franchise/level">Competition Level</a></li>
                        <!--<li class="divider"></li>-->
                        <!--<li><a href="<?php echo SITE_URL?>franchise/gen">Gen</a></li>-->
                        
                        <!--<li class="divider"></li>-->
                        <!--    <li><a href='<?php echo SITE_URL?>competitionshedule/competition_activate2'>Activate Competation</a></li>-->
                            
                        <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>franchise/admin_revenue_setting">Admin Revenue Setting</a></li>
                            
                        <!--<li class="divider"></li>-->
                        <!--    <li><a href="<?php echo SITE_URL?>franchise/admin_revenue_setting_filter">Admin Revenue Filter</a></li>-->
                        
                        <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>competitionshedule/launch_new_competition">Launch New Competition</a></li>
                            
                        
                        <li class="divider"></li>
                            <li><a href='<?php echo SITE_URL?>competitionshedule/competition_list'>Live Competation List</a></li>
                      
                       
                            
                        <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>competitionshedule/cmsch2">Schedule Assign School - Other than SchoolLevel</a></li>
                
                       
                        <li class="divider"></li>                      
                            <li><a href="<?php echo SITE_URL?>competitionshedule/search_school1">School QR - Other Than SchoolLevel</a></li>   
                             
                        <li class="divider"></li>
                            <li><a href='<?php echo SITE_URL?>competitionshedule/mark_cin'>Mark CIN as registered</a></li>
                            
                        <li class="divider"></li>
                            <li><a href='<?php echo SITE_URL?>competitionshedule/unmark_cin'>Mark CIN as not registered</a></li>
                       <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>franchise/cin_login_activate">Activate Open Champtioship</a></li>
                        
                      
    			    </ul>
				  </li>
				  
			   
			    <!--  ============== Activate new session and level =============== -->
			    <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/search_material'
			    ,base_url().'manage/franchise/study_material_2021'))){?> active<?php }?>">
                <a class="dropdown-toggle " data-toggle="dropdown" href="#">Study Material <b class="caret"></b></a>
                <ul class="dropdown-menu">
                  
                    <li><a href="<?php echo SITE_URL?>franchise/study_material_2021">All Materials Upload</a></li>
                  
                        <li class="divider"></li>
                    <li><a href="<?php echo SITE_URL?>franchise/search_material">Material Search</a></li>
                        <li class="divider"></li>
                    <li><a href="<?php echo SITE_URL?>competitionshedule/mock_paper_upload_">Mock Paper Upload</a></li>
                    
                    <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>competitionshedule/mock_paper_search">Mock Paper Search</a></li>
                    <!--<li class="divider"></li>-->
                        <!--<li><a href="<?php echo SITE_URL?>competitionshedule/mock_paper_maker">Mock Paper Makers</a></li>-->
                    <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>competitionshedule/material_maker">Add Makers</a></li>
                        
                    <li class="divider"></li>
                        <li><a href="<?php echo SITE_URL?>franchise/assign_content">Assign Content</a></li>    
                        
			    </ul>
				  </li>
			   <!--  ============== Activate new session and level =============== -->
			   <!-- <li class="dropdown <?php if(in_array(CONTROLLER,array('franchise'))){?> active<?php }?>">-->
      <!--          <a class="dropdown-toggle " data-toggle="dropdown" href="#">2021-22 Extraction<b class="caret"></b></a>-->
      <!--          <ul class="dropdown-menu">-->
                  
      <!--              <li><a href="<?php echo SITE_URL?>franchise/orientatition_extract">Orientation Extraction List</a></li>-->
                  
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/competition_extraction">Competition Extraction List</a></li>-->
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/mock_test">Mock Test Extraction List</a></li>-->
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/study_material">Study Material Extraction List</a></li>-->
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/rivision">Revision Extraction List</a></li>-->
      <!--                  <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/not_applied">Not Applied Anything</a></li>-->
			   <!-- </ul>-->
				  <!--</li>-->
			   
			   
			   
			 <!--   <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/cin_login_activate'))){?> active<?php }?>">-->
    <!--                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Activate cin login products<b class="caret"></b></a>-->
    <!--                    <ul class="dropdown-menu">-->
                          
                           
                          
                            
    <!--    			    </ul>-->
				<!--</li>-->
				  
				<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/lunar'))){?> active<?php }?>">
                        <a class="dropdown-toggle " data-toggle="dropdown" href="#">Rank List<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                          
                            <li><a href="<?php echo SITE_URL?>lunar/upload_rank">Upload Rank List</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>lunar/filter_rank">Rank List Export</a></li>
                            
                            
                            
                            
        			    </ul>
				</li>  
				  
				  
    <!--            <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/lunar'))){?> active<?php }?>">-->
    <!--                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Lunar Olympiads<b class="caret"></b></a>-->
    <!--                    <ul class="dropdown-menu">-->
                          
                            <!--<li><a href="<?php echo SITE_URL?>lunar/export_cin">Registered Export</a></li>-->
                            <!--<li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/export_cin_all">CIN Export</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/upload_result">Upload Result</a></li>-->
                            
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/export_result">Result Export</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/schedule_lunar">Activate New Series</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/schedule_list">Active Competition List</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/lunarcompetition_activate">Assign Series To Cart</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/add_subject">Add Subject</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/add_varient">Add Variant</a></li>-->
    <!--    			    </ul>-->
				<!--</li>-->
				
				<!--<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/zoomzoom'))){?> active<?php }?>">-->
    <!--                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Math ZoomZoom<b class="caret"></b></a>-->
    <!--                    <ul class="dropdown-menu">-->
                          
                            
    <!--                        <li><a href="<?php echo SITE_URL?>zoomzoom/admin_revenue_and_competition">Launch Competition</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>zoomzoom/schedule_list">Active Competition List</a></li>-->
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/export_cin">Registered Export</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>zoomzoom/export_cin_all">CIN Export Registered Online</a></li>-->
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/upload_result">Upload Result</a></li>-->
                            
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/export_result">Result Export</a></li>-->
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/schedule_lunar">Activate To Generate CIN</a></li>-->
                            
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/lunarcompetition_activate">Assign Schedule Cart</a></li>-->
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/add_subject">Add Subject</a></li>-->
                            <!--<li class="divider"></li>-->
                            <!--<li><a href="<?php echo SITE_URL?>zoomzoom/add_varient">Add Variant</a></li>-->
    <!--    			    </ul>-->
				<!--</li>-->
				  
		<li class="dropdown modern-dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        Online Programs <b class="caret"></b>
    </a>

    <ul class="dropdown-menu modern-menu">

        <!-- ===== Lunar Skill Tests ===== -->
        <li class="dropdown-submenu">
            <a href="#">
                Lunar Skill Tests
                <span class="arrow">▶</span>
            </a>

            <ul class="dropdown-menu">
                <li><a href="<?php echo SITE_URL?>lunar/export_cin_all">CIN Export</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/upload_result">Upload Result</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/export_result">Result Export</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/schedule_lunar">Activate New Series</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/schedule_list">Active Competition List</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/lunarcompetition_activate">Assign Series To Cart</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/add_subject">Add Subject</a></li>
                <li><a href="<?php echo SITE_URL?>lunar/add_varient">Add Variant</a></li>
            </ul>
        </li>

        <li class="divider"></li>

        <!-- ===== Zoom Zoom ===== -->
        <li class="dropdown-submenu">
            <a href="#">
                MaRRS Zoom Zoom Challenge
                <span class="arrow">▶</span>
            </a>

            <ul class="dropdown-menu">
                <li><a href="<?php echo SITE_URL?>zoomzoom/admin_revenue_and_competition">Launch Competition</a></li>
                <li><a href="<?php echo SITE_URL?>zoomzoom/schedule_list">Active Competition List</a></li>
                <li><a href="<?php echo SITE_URL?>zoomzoom/export_cin_all">CIN Export Registered Online</a></li>
            </ul>
        </li>

    </ul>
</li>

			    <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/lunar'))){?> active<?php }?>">
                        <a class="dropdown-toggle " data-toggle="dropdown" href="#">Associate<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo SITE_URL?>lunar/add_associate">Add Associate</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>lunar/update_associate">Update Associate</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>lunar/competitionlist_associate">Activate Competition Link</a></li>
                            
        			    </ul>
				</li>
				  
			 <!--   <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/lunar'))){?> active<?php }?>">-->
    <!--                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Schedule Lunar<b class="caret"></b></a>-->
    <!--                    <ul class="dropdown-menu">-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/lunarcompetition_activate">Add Schedule</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>lunar/update_schedulelist">List/Update Schedule</a></li>-->
    <!--    			    </ul>-->
				<!--</li>-->
				  
				  
				<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/cin_genration',base_url().'manage/franchise/cin_list',base_url().'manage/franchise/cin_list_export',base_url().'manage/franchise/cin_list_export_offline'))){?> active<?php }?>">
                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">CIN Generation<b class="caret"></b></a>
                        <ul class="dropdown-menu">  
                      
        				    <li><a href="<?php echo base_url();?>public/template/MARRS_CIN_GENERATIION_TEMPLATE.csv"> CIN Template </a></li>
        					<li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>franchise/cin_genration">Add CIN </a></li>
                            
                            <!--<li><a href="<?php echo SITE_URL?>competitionshedule/cin_genration">Add CIN </a></li>-->
                            
        					<li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>franchise/cin_list">List Of recent CIN </a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>franchise/cin_list_latest">List Of Recent online registered </a></li>
                              <li class="divider"></li>
                                <li><a href="<?php echo SITE_URL?>franchise/cin_list_export">CIN Extract (2023/24)</a></li>
                             <!--<li class="divider"></li>-->
                             <!--   <li><a href="<?php echo SITE_URL?>franchise/cin_list_export_offline">CIN Extract all Registered (2023/24)</a></li> -->
                             <li class="divider"></li>
                                <li><a href="<?php echo SITE_URL?>franchise/cin_profile_update">CIN Update Profile</a></li>
                               <li class="divider"></li>
                            <li><a href="<?php echo SITE_URL?>competitionshedule/delete_cin">Delete CIN</a></li>
                        
                        
			        </ul>
				</li>
				  
				  
				  
			     <li class="dropdown  <?php if(in_array(CONTROLLER,array('school'))){?> active <?php }?>">
      
      
      
      <!--          <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/school'))){?> active<?php }?>">-->
      <!--              <a class="dropdown-toggle " data-toggle="dropdown" href="#">  Registered Students 23-above<b class="caret"></b></a>-->
      <!--              <ul class="dropdown-menu"> -->
                              
    		<!--				   <li><a href="<?php echo SITE_URL?>school/competition_extraction">Competition Extract </a> </li>-->
      <!--                          <li class="divider"></li> -->
      <!--                          <li><a href="<?php echo SITE_URL?>school/mock_extraction">Mock Extract </a> </li>-->
                                <!--<li><a href="<?php echo SITE_URL?>school/cin_list_export">ALL Extract 2023-24 </a> </li>-->
      <!--                          <li class="divider"></li> -->
      <!--                          <li><a href="<?php echo SITE_URL?>school/material_extraction">Material Extract </a> </li>-->
      <!--                           <li class="divider"></li> -->
      <!--                          <li><a href="<?php echo SITE_URL?>school/orientation_extraction">Orientation Extract </a> </li>-->
      <!--              </ul>      -->
                    
      <!--          </li>-->
			   
			   
			   
			    <!--  ============== Activate new session and level =============== -->
			   <!-- <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/Cin_extract',base_url().'manage/franchise/Cin_extract_orientation',base_url().'manage/franchise/Cin_extract_mock',base_url().'manage/franchise/Cin_extract_material'))){?> active<?php }?>">-->
      <!--          <a class="dropdown-toggle " data-toggle="dropdown" href="#">  Registered Students Till 2022/23<b class="caret"></b></a>-->
      <!--          <ul class="dropdown-menu">-->
                  
      <!--              <li><a href="<?php echo SITE_URL?>franchise/Cin_extract">Competition Extraction List</a></li>-->
                  
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_orientation">Orientation Extraction List</a></li>-->
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_mock">Mock Test Extraction List</a></li>-->
      <!--              <li class="divider"></li>-->
      <!--                  <li><a href="<?php echo SITE_URL?>franchise/Cin_extract_material">Study Material Extraction List</a></li>-->
                    <!--<li class="divider"></li>-->
                    <!--    <li><a href="<?php echo SITE_URL?>franchise/rivision">Revision Extraction List</a></li>-->
                    <!--    <li class="divider"></li>-->
                    <!--    <li><a href="<?php echo SITE_URL?>franchise/not_applied">Not Applied Anything</a></li>-->
			   <!-- </ul>-->
				  <!--</li>-->
		

			   
			   <!-- <li class="dropdown <?php if(in_array(CONTROLLER,array('franchise'))){?> active<?php }?>">-->
      <!--          <a class="dropdown-toggle " data-toggle="dropdown" href="#">ZoomZoom Material Upload<b class="caret"></b></a>-->
      <!--          <ul class="dropdown-menu">-->
                  
      <!--              <li><a href="<?php echo SITE_URL?>franchise/study_material_zoomzoom">Upload Material</a></li>-->
                  
                    
			   <!-- </ul>-->
				  <!--</li>-->
				  
				<li class="dropdown  <?php if(in_array(current_url(),array(base_url().'manage/franchise/zoomzoom_export'))){?> active<?php }?>">
                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">ZoomZoom Extract 22/23<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo SITE_URL?>franchise/zoomzoom_export">Zoomzoom Export</a></li>
    			    </ul>
				</li>
				  
				  
			 <!--   <li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/search_school'))){?> active<?php }?>">-->
    <!--                <a class="dropdown-toggle " data-toggle="dropdown">School Level Registration<b class="caret"></b></a>-->
    <!--                <ul class="dropdown-menu">-->
                      
    <!--                        <li><a href="<?php echo SITE_URL?>franchise/search_school">School QR</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/cmsch">Competition Schedule Assign School</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                        <li><a href="<?php echo SITE_URL?>franchise/edit_search_school">Edit Competition Schedule Assign School</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/split_pay">Payment Split Details</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/cin_prid_extract">CIN Extract</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/activate_orientation">Activate Orientation</a></li>-->
    <!--			    </ul>-->
				<!--</li>-->
				  
				<!--<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/franchise/search_school'))){?> active<?php }?>">-->
    <!--                <a class="dropdown-toggle " data-toggle="dropdown">Promotional Schools<b class="caret"></b></a>-->
    <!--                <ul class="dropdown-menu">-->
                      
    <!--                        <li><a href="<?php echo SITE_URL?>franchise/assign_product">Assign Products School</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/school_list">School List</a></li>-->
    <!--                        <li class="divider"></li>-->
    <!--                            <li><a href="<?php echo SITE_URL?>franchise/student_list">Students List</a></li>-->
                            
    <!--			    </ul>-->
				<!--</li>  -->
				  
				  
				<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/competitionshedule/profile_extract'))){?> active<?php }?>">
                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Extract CIN Prifile+SchoolLevel Result<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      
                        <li><a href="<?php echo SITE_URL?>competitionshedule/profile_extract">Get Profile and Result</a></li>
                      
                        
    			    </ul>
				</li> 
				  
				  
				  
				  
				<li class="dropdown <?php if(in_array(current_url(),array(base_url().'manage/competitionshedule/cin_enquiries'))){?> active<?php }?>">
                    <a class="dropdown-toggle " data-toggle="dropdown" href="#">Support Enquiry<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      
                        <li><a href="<?php echo SITE_URL?>competitionshedule/cin_enquiries">Enquiries</a></li>
                      
                        
    			    </ul>
				</li>   
				  
				  
				  
				  
            </ul>
	<?php } ?>
	
	
<script>
  $(document).ready(function () {

    $('.dropdown-submenu > a').on("click", function (e) {
        e.preventDefault();
        e.stopPropagation();

        let parent = $(this).parent();

        // close others
        $('.dropdown-submenu').not(parent).removeClass('open');

        // toggle current
        parent.toggleClass('open');
    });

});
</script>		
			

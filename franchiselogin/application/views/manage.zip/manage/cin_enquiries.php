<?php include('header.php');
//print_r($area);
?>
<?php echo $this->notifications->display_html();?> 
			<div>
				<ul class="breadcrumb">
					<li>
						<a href="<?php echo SITE_URL?>content/">CIN</a> <span class="divider">/</span>
					</li>
					<li>
							<a href="<?php echo SITE_URL?>content/">Enquiry</a>
					</li>
				</ul>
			</div>
			
     <form method="POST">
			<div>		
				<div class="box span12">
					<div class="box-header well" data-original-title>
						<h2><i class="icon-user"></i> CIN-Enquiry</h2>
						<div class="box-icon">
							<a href="#" class="btn btn-minimize btn-round"><i class="icon-chevron-up"></i></a>
							<a href="#" class="btn btn-close btn-round"><i class="icon-remove"></i></a>
						</div>
					</div>
					
					<div class="box-content">
                  <?php if(isset($message) && !empty($message)){ ?>
                    <h4><?php echo $message; ?></h4>
                  <?php } ?>
						<table class="table table-bordered" width="100%">
						    <form method="POST" class="row g-3">
						        
					 <div class="col-md-3">
                    <label class="form-label">State <span style="color:red;">*</span></label>
                    <select name="state_id" class="form-control" required>
                        <option value=''>-- select state --</option>
                        <?php foreach($stateload as $stateload){ ?>
                        <option value="<?php echo $stateload['state_subdivision_id'] ?>" <?php if(isset($result['state_id']) && $stateload['state_subdivision_id']==$result['state_id']){?> selected="selected" <?php } ?> ><?php echo $stateload['state_subdivision_name'] ?></option>;
                        <?php } ?>
                     </select>    
                </div>	 
                <div class="col-md-3">
                    <label class="form-label">Product<span style="color:red;">*</span></label>
                    <select name="product" class="form-control" required>
                        <option value=''>-- select product --</option>
                        <?php foreach($productload as $stateload){ ?>
                        <option value="<?php echo $stateload['product_name'] ?>" <?php if(isset($result['product']) && $stateload['product_name']==$result['product']){?> selected="selected" <?php } ?> ><?php echo $stateload['product_name'] ?></option>;
                        <?php } ?>
                     </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Enquiry Start Date <span style="color:red;">*</span></label>
                    <input type="date" name="start_date" class="form-control" value='<?php if(isset($result['start_date'])){ echo $result['start_date'];} ?>' required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Enquiry End Date <span style="color:red;">*</span></label>
                    <input type="date" name="end_date" class="form-control" value='<?php if(isset($result['end_date'])){ echo $result['end_date'];} ?>' required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Type <span style="color:red;">*</span></label>
                    <select name="enquiry_type" class="form-control" required>
                        <option value='1' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==1){?> selected='selected' <?php } ?>>General Enquiry</option>
                        <option value='2' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==2){?> selected='selected' <?php } ?>>Registration/Admit Card Not Active</option>
                        <option value='3' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==3){?> selected='selected' <?php } ?>>Material Not Active</option>
                        <option value='4' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==4){?> selected='selected' <?php } ?>>Orientation Not Active</option>
                        <option value='5' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==5){?> selected='selected' <?php } ?>>Mock Paper Not Active</option>
                        <option value='6' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==6){?> selected='selected' <?php } ?>>Tech Team Support</option>
                        <option value='7' <?php if(isset($result['enquiry_type']) && $result['enquiry_type']==7){?> selected='selected' <?php } ?>>Combo Purchase Issue</option>
                    </select>    
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status <span style="color:red;">*</span></label>
                    <select name="status" class="form-control" required>
                        <option value='open' <?php if(isset($result['status']) && $result['status']=='Open'){?> selected='selected' <?php } ?>>Open</option>
                        <option value='Closed' <?php if(isset($result['status']) && $result['status']=='Closed'){?> selected='selected' <?php } ?>>Closed</option>
                    </select>    
                </div>
                <div class="col-md-3">
                    <input type="submit" name="submit" value="Search" class="btn btn-primary mt-4">
                </div>
            </form>
						   
						</table>
							 
					</div>
					<div class="box-content">
                  
						<table class="table table-bordered" width="100%">
						  <thead>
						      
							  <tr>
								  <th>SL No.</th>
								  <th>CIN</th>
								  <th>Student Name</th>
								  <th>Enquiry Type</th>
								  <th>Enquiry</th>
                                  <th>Evidence</th>
                                    
                                  <th>Status</th>
                                   <!--<th>Class</th>-->
                                  <!--<th>Actions</th>-->
                                  <!--<th>Delete</th>-->
							  </tr>
						  </thead>   
						  <tbody>
						    <?php  if(!empty($cin_list)){
						    
						    ?>
						    <form method='POST'> 
							    <tr>
							        <input type='hidden' name='sch' value='<?php print_r($sch); ?>'>
							        <input type='hidden' name='cla' value='<?php print_r($cla) ?>'>
							        <input type="submit" name="export" value="export" class='btn btn-primary' />
							    </tr>
							</form>
							<?php } ?>
							<?php $i=1;foreach($registration_details as $value ) { 
				// 			print_r($value);
							?>
							
							<tr>
                                <td><?php echo $i; ?></td>
								<!--<td><a><?php echo $value['cin']; ?></a></td>-->
								<td>
                                    <a href="javascript:void(0);" onclick="openCompetitionScheduleModal('<?php echo $value['cin']; ?>')">
                                        <?php echo $value['cin']; ?>
                                    </a>
                                </td>

								
                              <td><?php echo $value['student_name']; ?></td>
                                  <td><?php echo $value['enquiry_name']; ?></td>
								    <td><?php echo $value['enquiry']; ?></td>
                                    <td>
                                        <?php if(!empty($value['evidence'])){ ?>
                                        <img src="https://marrs.in/student_registration/images/evidence/<?php echo $value['evidence']; ?>" style='height:200px;width:150px;'>
                                        <?php } ?>
                                    </td>
                                    <td >
								<?php echo $value['status']; ?>
								</td>
                                  <!--<td><?php echo $value['class']; ?></td>-->
                                 
								<!--<td class="center">-->
								
								<!--	<a class="btn btn-info" href="" title="Edit">-->
								<!--		Edit                              -->
								<!--	</a>-->
								<!--</td>-->
								
								<!--<td class="center">-->
								<!--<form method='POST'>-->
								<!--    <input type='hidded' name='enquiry_id' value='<?php echo $value['enquiry_id']; ?>'>-->
								<!--	<input type='submit' name='status' class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');" value="<?php if($value['status']=='Close'){ echo 'Open';}else{echo 'Close';} ?>" >-->
								<!--</form>	-->
								<!--</td>-->
								
							</tr>
						<?php $i++; } ?>	
						
						   
						  </tbody>
					  </table> 
					
					<div class="pagination pagination-left">
						 <ul>
							<li><a href="#">Prev</a></li>
							<li><a href="#">1</a></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#">Next</a></li>
						  </ul>
					</div>
				
				
			
					
					
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
			
</form>


<div id="competitionModal" class="modal" style="display:none;">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal();">&times;</span>
        <div class="modal-header">
            <h2>Competition Details</h2>
        </div>
        <div class="modal-body">
            <!-- Profile Section -->
            <div class="modal-section profile-section">
                <h3>Profile Details</h3>
                <div id="profile-details">
                    <!-- Dynamic profile details will be loaded here -->
                </div>
            </div>

            <!-- Results Section -->
            <div class="modal-section results-section">
                <h3>Level-wise Results</h3>
                <div id="results-details">
                    <!-- Dynamic results details will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: relative;
}

.close-btn {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close-btn:hover,
.close-btn:focus {
    color: black;
    text-decoration: none;
}

h3 {
    margin-top: 0;
}

table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 15px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    text-align: left;
    padding: 8px;
}

th {
    background-color: #f2f2f2;
}

</style>

<script src="<?php echo VIEW_SCRIPT;?>jquery-1.9.1.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js" ></script>
<script type="text/javascript">
    $("#area_code").change(function(){
    var area_code =this.value;
    //  alert('area_code');
        var BASE_URL="https://marrs.in/franchiselogin/";
        $.ajax({
        url:"https://marrs.in/franchiselogin/manage/ajax/school_list",
        data:{area_code:area_code},
        type: 'post',
        success:function(result)
        {
        	//alert(result);
        	 $("#school").html(result);
        	 
        
        }});
    });
    
    
    function openCompetitionScheduleModal(cin) {
    // Show the modal
    document.getElementById('competitionModal').style.display = 'block';

    // Fetch data from the controller
    const baseUrl = "<?php echo base_url(); ?>";
    const url = baseUrl + "competitionshedule/get_cindata";
    
    // Make an AJAX request
    $.ajax({
        url: url,
        type: 'POST',
        data: { cin: cin },
        success: function (response) {
            // Parse JSON response
            const data = JSON.parse(response);
            
            if (data.error) {
                document.getElementById('modal-body').innerHTML = `<p>${data.error}</p>`;
            } else {
                // Populate profile section
                const profileHtml = `
                    <h3>Profile Details</h3>
                    <p><strong>Name:</strong> ${data.profile.student_name}</p>
                    <p><strong>Class:</strong> ${data.profile.class}</p>
                    <p><strong>School:</strong> ${data.profile.school_name}</p>
                `;

                // Populate results section
                let resultsHtml = '<h3>Results</h3><table border="1" width="100%"><tr><th>Level Name</th><th>Product Name</th><th>Status</th><th>Marks</th></tr>';
                data.results.forEach(result => {
                    resultsHtml += `
                        <tr>
                            <td>${result.level_name}</td>
                            <td>${result.product_name}</td>
                            <td>${result.status}</td>
                            <td>${result.marks}</td>
                        </tr>
                    `;
                });
                resultsHtml += '</table>';

                document.getElementById('modal-body').innerHTML = profileHtml + resultsHtml;
            }
        },
        error: function (xhr, status, error) {
            // Handle error
            document.getElementById('modal-body').innerHTML = "<p>Error loading data. Please try again.</p>";
            console.error('Error:', error);
        }
    });
}

function closeModal() {
    // Hide the modal
    document.getElementById('competitionModal').style.display = 'none';
}


</script>


<?php include('footer.php');?>